import mongoose, { Schema } from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();

// Connect to MongoDB
const MONGODB_URI = process.env.MONGODB_URI;

export const isMongoConnected = () => mongoose.connection.readyState === 1;

if (MONGODB_URI) {
  mongoose.connect(MONGODB_URI)
    .then(() => console.log('Successfully connected to MongoDB.'))
    .catch((err) => console.error('MongoDB connection error:', err));
} else {
  console.warn('WARNING: MONGODB_URI is not set. Real MongoDB queries will fallback to in-memory store.');
}

// User Schema
const UserSchema = new Schema({
  id: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  course: { type: String, default: '' },
  year: { type: String, default: '' },
  avatarUrl: { type: String, default: '' }
}, { id: false });

// Task Schema
const TaskSchema = new Schema({
  id: { type: String, required: true, unique: true },
  title: { type: String, required: true },
  description: { type: String, default: '' },
  completed: { type: Boolean, default: false },
  priority: { type: String, default: 'medium' },
  dueDate: { type: String, default: '' },
  userId: { type: String, default: '' },
  completedDate: { type: String, default: '' },
  createdAt: { type: Date, default: Date.now }
}, { id: false });

// Timetable Schema
const TimetableSchema = new Schema({
  id: { type: String, required: true, unique: true },
  subject: { type: String, required: true },
  day: { type: String, required: true },
  time: { type: String, default: '' },
  room: { type: String, default: '' },
  teacher: { type: String, default: '' },
  duration: { type: Number, default: 45 }
}, { id: false });

// Subject-specific Attendance Schema
const AttendanceSchema = new Schema({
  id: { type: String, required: true, unique: true },
  subject: { type: String, required: true },
  present: { type: Number, default: 0 },
  total: { type: Number, default: 0 }
}, { id: false });

// Daily Calendar Attendance Schema (timetable_daily_attendance)
const DailyAttendanceSchema = new Schema({
  dateStr: { type: String, required: true, unique: true },
  status: { type: String, required: true } // 'present' | 'absent'
});

// Mark Schema
const MarkSchema = new Schema({
  id: { type: String, required: true, unique: true },
  subject: { type: String, required: true },
  score: { type: Number, default: 0 },
  maxScore: { type: Number, default: 100 },
  type: { type: String, default: 'Exam' },
  date: { type: String, default: '' }
}, { id: false });

// Note Schema
const NoteSchema = new Schema({
  id: { type: String, required: true, unique: true },
  title: { type: String, required: true },
  content: { type: String, default: '' },
  userId: { type: String, default: '' }
}, { id: false });

// Habit Schema
const HabitSchema = new Schema({
  id: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  category: { type: String, default: '' },
  detail: { type: String, default: '' },
  completed: { type: Boolean, default: false },
  streak: { type: Number, default: 0 },
  completedDate: { type: String, default: '' },
  userId: { type: String, default: '' },
  createdAt: { type: Date, default: Date.now }
}, { id: false });

// Notification Schema
const NotificationSchema = new Schema({
  id: { type: String, required: true, unique: true },
  title: { type: String, required: true },
  description: { type: String, default: '' },
  type: { type: String, default: 'info' },
  time: { type: String, default: 'Just now' },
  read: { type: Boolean, default: false }
}, { id: false });

// Settings Schema
const SettingsSchema = new Schema({
  darkMode: { type: Boolean, default: false },
  notifications: { type: Boolean, default: true }
});

// File Schema
const FileSchema = new Schema({
  id: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  url: { type: String, required: true }
}, { id: false });

// Ensure models are registered and exported directly with exact TypeScript typings
export const UserModel = mongoose.model('User', UserSchema);
export const TaskModel = mongoose.model('Task', TaskSchema);
export const TimetableModel = mongoose.model('Timetable', TimetableSchema);
export const AttendanceModel = mongoose.model('Attendance', AttendanceSchema);
export const DailyAttendanceModel = mongoose.model('DailyAttendance', DailyAttendanceSchema);
export const MarkModel = mongoose.model('Mark', MarkSchema);
export const NoteModel = mongoose.model('Note', NoteSchema);
export const HabitModel = mongoose.model('Habit', HabitSchema);
export const NotificationModel = mongoose.model('Notification', NotificationSchema);
export const SettingsModel = mongoose.model('Settings', SettingsSchema);
export const FileModel = mongoose.model('File', FileSchema);
