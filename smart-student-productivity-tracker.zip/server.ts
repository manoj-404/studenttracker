import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import {
  UserModel,
  TaskModel,
  TimetableModel,
  AttendanceModel,
  DailyAttendanceModel,
  MarkModel,
  NoteModel,
  HabitModel,
  NotificationModel,
  SettingsModel,
  FileModel,
  isMongoConnected
} from './models.ts';

dotenv.config();

const app = express();
const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'super-secret-key';

// Middleware
app.use(cors());
app.use(express.json());

// In-memory fallback dataset in case MongoDB connection string is not set
const localDb = {
  users: [] as any[],
  tasks: [] as any[],
  attendance: [] as any[],
  timetable: [] as any[],
  marks: [] as any[],
  notes: [] as any[],
  habits: [] as any[],
  files: [] as any[],
  notifications: [
    { id: '1', title: 'Welcome!', description: 'Thanks for joining StudySync.', type: 'info', time: 'Just now', read: false }
  ] as any[],
  settings: {
    darkMode: false,
    notifications: true
  }
};

// --- AUTH MIDDLEWARE ---
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.status(401).json({ message: 'No token provided' });

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.status(403).json({ message: 'Invalid token' });
    req.user = user;
    next();
  });
};

// --- API ROUTES (v1) ---
const api = express.Router();

// 1. Auth APIs
api.post('/auth/register', async (req, res) => {
  try {
    const { name, email, password, course, year } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const userId = `u${Date.now()}`;
    const newUser = { id: userId, name, email, password: hashedPassword, course: course || '', year: year || '', avatarUrl: '' };

    if (isMongoConnected()) {
      // Check for existing user first
      const existing = await UserModel.findOne({ email });
      if (existing) {
        return res.status(400).json({ message: 'User with this email already exists' });
      }
      await new UserModel(newUser).save();
    } else {
      const existing = localDb.users.find(u => u.email === email);
      if (existing) {
        return res.status(450).json({ message: 'User already exists' });
      }
      localDb.users.push(newUser);
    }
    res.status(201).json({ message: 'User registered successfully' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    let user;

    if (isMongoConnected()) {
      user = await UserModel.findOne({ email });
    } else {
      user = localDb.users.find((u: any) => u.email === email);
    }

    if (user && await bcrypt.compare(password, user.password)) {
      const token = jwt.sign({ id: user.id, name: user.name }, JWT_SECRET);
      res.json({ token, user: { id: user.id, name: user.name } });
    } else {
      res.status(401).json({ message: 'Invalid credentials' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.get('/auth/me', authenticateToken, async (req: any, res) => {
  try {
    let user;
    if (isMongoConnected()) {
      user = await UserModel.findOne({ id: req.user.id });
    } else {
      user = localDb.users.find((u: any) => u.id === req.user.id);
    }

    if (user) {
      const { password, ...safeUser } = (user.toObject ? user.toObject() : user);
      res.json(safeUser);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.post('/auth/logout', authenticateToken, (req, res) => {
  res.json({ message: 'Logged out successfully' });
});

// 2. User APIs
api.get('/users/:id', authenticateToken, async (req, res) => {
  try {
    let user;
    if (isMongoConnected()) {
      user = await UserModel.findOne({ id: req.params.id });
    } else {
      user = localDb.users.find((u: any) => u.id === req.params.id);
    }

    if (user) {
      const { password, ...safeUser } = (user.toObject ? user.toObject() : user);
      res.json(safeUser);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.put('/users/:id', authenticateToken, async (req: any, res) => {
  try {
    if (req.user.id !== req.params.id) return res.status(403).json({ message: 'Forbidden' });
    
    let updated;
    if (isMongoConnected()) {
      updated = await UserModel.findOneAndUpdate({ id: req.params.id }, req.body, { new: true });
    } else {
      const index = localDb.users.findIndex((u: any) => u.id === req.params.id);
      if (index !== -1) {
        localDb.users[index] = { ...localDb.users[index], ...req.body };
        updated = localDb.users[index];
      }
    }

    if (updated) {
      const { password, ...safeUser } = (updated.toObject ? updated.toObject() : updated);
      res.json(safeUser);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.post('/users/upload-avatar', authenticateToken, (req, res) => {
  res.json({ success: true, avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop' });
});

// 3. Dashboard API
api.get('/dashboard', authenticateToken, async (req: any, res) => {
  try {
    let pendingTasksCount = 0;
    let unreadNotificationsCount = 0;

    if (isMongoConnected()) {
      pendingTasksCount = await TaskModel.countDocuments({ userId: req.user.id, completed: false });
      unreadNotificationsCount = await NotificationModel.countDocuments({ read: false });
    } else {
      pendingTasksCount = localDb.tasks.filter((t: any) => t.userId === req.user.id && !t.completed).length;
      unreadNotificationsCount = localDb.notifications.filter(n => !n.read).length;
    }

    res.json({
      attendance: 82, // Standard metric, or customized
      gpa: 8.5,
      pendingTasks: pendingTasksCount,
      notifications: unreadNotificationsCount,
      aiSuggestion: "Maintain consistency matching your 80% attendance goals."
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 4. Tasks APIs
api.get('/tasks', authenticateToken, async (req: any, res) => {
  try {
    if (isMongoConnected()) {
      const tasks = await TaskModel.find({ userId: req.user.id });
      res.json(tasks);
    } else {
      res.json(localDb.tasks.filter((t: any) => t.userId === req.user.id));
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.post('/tasks', authenticateToken, async (req: any, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const isDone = req.body.completed || req.body.status === 'Done';
    const task = {
      id: Date.now().toString(),
      title: req.body.title || '',
      description: req.body.description || '',
      completed: isDone,
      completedDate: isDone ? today : '',
      priority: req.body.priority || 'medium',
      dueDate: req.body.dueDate || 'No Date',
      userId: req.user.id,
      createdAt: new Date()
    };
    
    if (isMongoConnected()) {
      await new TaskModel(task).save();
    } else {
      localDb.tasks.push(task);
    }
    res.status(201).json(task);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.put('/tasks/:id', authenticateToken, async (req, res) => {
  try {
    let updated;
    const today = new Date().toISOString().split('T')[0];
    const updatePayload = { ...req.body };
    if (updatePayload.completed !== undefined) {
      updatePayload.completedDate = updatePayload.completed ? today : '';
    } else if (updatePayload.status !== undefined) {
      updatePayload.completed = updatePayload.status === 'Done';
      updatePayload.completedDate = updatePayload.completed ? today : '';
    }

    if (isMongoConnected()) {
      updated = await TaskModel.findOneAndUpdate({ id: req.params.id }, updatePayload, { new: true });
    } else {
      const index = localDb.tasks.findIndex((t: any) => t.id === req.params.id);
      if (index !== -1) {
        localDb.tasks[index] = { ...localDb.tasks[index], ...updatePayload };
        updated = localDb.tasks[index];
      }
    }

    if (updated) {
      res.json(updated);
    } else {
      res.status(404).json({ message: 'Task not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.delete('/tasks/:id', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected()) {
      await TaskModel.deleteOne({ id: req.params.id });
    } else {
      localDb.tasks = localDb.tasks.filter((t: any) => t.id !== req.params.id);
    }
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.patch('/tasks/:id/status', authenticateToken, async (req: any, res) => {
  try {
    let updated;
    const today = new Date().toISOString().split('T')[0];
    if (isMongoConnected()) {
      const task = await TaskModel.findOne({ id: req.params.id });
      if (task) {
        const newCompleted = req.body.completed !== undefined ? req.body.completed : !task.completed;
        task.completed = newCompleted;
        task.completedDate = newCompleted ? today : '';
        await task.save();
        updated = task;
      }
    } else {
      const task = localDb.tasks.find((t: any) => t.id === req.params.id);
      if (task) {
        const newCompleted = req.body.completed !== undefined ? req.body.completed : !task.completed;
        task.completed = newCompleted;
        task.completedDate = newCompleted ? today : '';
        updated = task;
      }
    }

    if (updated) {
      res.json(updated);
    } else {
      res.status(404).json({ message: 'Task not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.patch('/tasks/:id/complete', authenticateToken, async (req: any, res) => {
  try {
    let updated;
    const today = new Date().toISOString().split('T')[0];
    if (isMongoConnected()) {
      updated = await TaskModel.findOneAndUpdate({ id: req.params.id }, { completed: true, completedDate: today }, { new: true });
    } else {
      const task = localDb.tasks.find((t: any) => t.id === req.params.id);
      if (task) {
        task.completed = true;
        task.completedDate = today;
        updated = task;
      }
    }

    if (updated) {
      res.json(updated);
    } else {
      res.status(404).json({ message: 'Task not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 5. Timetable APIs
api.get('/timetable', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected()) {
      const list = await TimetableModel.find();
      res.json(list);
    } else {
      res.json(localDb.timetable);
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.post('/timetable', authenticateToken, async (req, res) => {
  try {
    const entry = { id: Date.now().toString(), ...req.body };
    if (isMongoConnected()) {
      await new TimetableModel(entry).save();
    } else {
      localDb.timetable.push(entry);
    }
    res.status(201).json(entry);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.put('/timetable/:id', authenticateToken, async (req, res) => {
  try {
    let updated;
    if (isMongoConnected()) {
      updated = await TimetableModel.findOneAndUpdate({ id: req.params.id }, req.body, { new: true });
    } else {
      const index = localDb.timetable.findIndex((e: any) => e.id === req.params.id);
      if (index !== -1) {
        localDb.timetable[index] = { ...localDb.timetable[index], ...req.body };
        updated = localDb.timetable[index];
      }
    }

    if (updated) {
      res.json(updated);
    } else {
      res.status(404).json({ message: 'Entry not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.delete('/timetable/:id', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected()) {
      await TimetableModel.deleteOne({ id: req.params.id });
    } else {
      localDb.timetable = localDb.timetable.filter((e: any) => e.id !== req.params.id);
    }
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 6. Attendance APIs (Subject-specific log)
api.get('/attendance', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected()) {
      const records = await AttendanceModel.find();
      res.json(records);
    } else {
      res.json(localDb.attendance);
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.post('/attendance', authenticateToken, async (req, res) => {
  try {
    const record = { id: Date.now().toString(), ...req.body };
    if (isMongoConnected()) {
      // Find and update or create
      const existing = await AttendanceModel.findOne({ subject: req.body.subject });
      if (existing) {
        Object.assign(existing, req.body);
        await existing.save();
        res.json(existing);
      } else {
        const created = await new AttendanceModel(record).save();
        res.json(created);
      }
    } else {
      const idx = localDb.attendance.findIndex(a => a.subject === req.body.subject);
      if (idx !== -1) {
        localDb.attendance[idx] = { ...localDb.attendance[idx], ...req.body };
        res.json(localDb.attendance[idx]);
      } else {
        localDb.attendance.push(record);
        res.json(record);
      }
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.put('/attendance/:id', authenticateToken, async (req, res) => {
  try {
    let updated;
    if (isMongoConnected()) {
      updated = await AttendanceModel.findOneAndUpdate({ id: req.params.id }, req.body, { new: true });
    } else {
      const index = localDb.attendance.findIndex((r: any) => r.id === req.params.id);
      if (index !== -1) {
        localDb.attendance[index] = { ...localDb.attendance[index], ...req.body };
        updated = localDb.attendance[index];
      }
    }

    if (updated) {
      res.json(updated);
    } else {
      res.status(404).json({ message: 'Record not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.get('/attendance/analytics', authenticateToken, async (req, res) => {
  try {
    let overall = 82;
    let lowAttendanceSubjects = ["Physics", "Mathematics"];

    if (isMongoConnected()) {
      const records = await AttendanceModel.find();
      if (records.length > 0) {
        let presents = 0;
        let totals = 0;
        const lows: string[] = [];
        records.forEach((r: any) => {
          presents += r.present || 0;
          totals += r.total || 0;
          const pct = r.total > 0 ? (r.present / r.total) * 100 : 100;
          if (pct < 80) lows.push(r.subject);
        });
        if (totals > 0) overall = Math.round((presents / totals) * 100);
        lowAttendanceSubjects = lows;
      }
    } else {
      if (localDb.attendance.length > 0) {
        let presents = 0;
        let totals = 0;
        const lows: string[] = [];
        localDb.attendance.forEach((r: any) => {
          presents += r.present || 0;
          totals += r.total || 0;
          const pct = r.total > 0 ? (r.present / r.total) * 100 : 100;
          if (pct < 80) lows.push(r.subject);
        });
        if (totals > 0) overall = Math.round((presents / totals) * 100);
        lowAttendanceSubjects = lows;
      }
    }

    res.json({ overall, lowAttendanceSubjects });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Daily calendar marks (timetable present/absent) APIs
api.get('/attendance/daily', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected()) {
      const logs = await DailyAttendanceModel.find();
      const mapped = logs.reduce((acc: any, curr: any) => {
        acc[curr.dateStr] = curr.status;
        return acc;
      }, {});
      res.json(mapped);
    } else {
      const logs = localStorageFallbackDb.dailyAttendance || {};
      res.json(logs);
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.post('/attendance/daily', authenticateToken, async (req, res) => {
  try {
    const { dateStr, status } = req.body; // status: 'present' | 'absent' | 'none'
    if (isMongoConnected()) {
      if (status === 'none') {
        await DailyAttendanceModel.deleteOne({ dateStr });
      } else {
        await DailyAttendanceModel.findOneAndUpdate({ dateStr }, { status }, { upsert: true, new: true });
      }
    } else {
      if (status === 'none') {
        delete localStorageFallbackDb.dailyAttendance[dateStr];
      } else {
        localStorageFallbackDb.dailyAttendance[dateStr] = status;
      }
    }
    res.json({ success: true, dateStr, status });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Temporary backend local storage bucket for daily attendance fallback
const localStorageFallbackDb = {
  dailyAttendance: {} as Record<string, string>
};

// 7. Marks APIs
api.get('/marks', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected()) {
      const list = await MarkModel.find();
      res.json(list);
    } else {
      res.json(localDb.marks);
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.post('/marks', authenticateToken, async (req, res) => {
  try {
    const mark = { id: Date.now().toString(), ...req.body };
    if (isMongoConnected()) {
      await new MarkModel(mark).save();
    } else {
      localDb.marks.push(mark);
    }
    res.json(mark);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.put('/marks/:id', authenticateToken, async (req, res) => {
  try {
    let updated;
    if (isMongoConnected()) {
      updated = await MarkModel.findOneAndUpdate({ id: req.params.id }, req.body, { new: true });
    } else {
      const index = localDb.marks.findIndex((m: any) => m.id === req.params.id);
      if (index !== -1) {
        localDb.marks[index] = { ...localDb.marks[index], ...req.body };
        updated = localDb.marks[index];
      }
    }

    if (updated) {
      res.json(updated);
    } else {
      res.status(404).json({ message: 'Mark not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.delete('/marks/:id', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected()) {
      await MarkModel.deleteOne({ id: req.params.id });
    } else {
      localDb.marks = localDb.marks.filter((m: any) => m.id !== req.params.id);
    }
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.get('/marks/analytics', authenticateToken, async (req, res) => {
  try {
    let average = 82;
    let trend = 'improving';
    let subjectPerformance = [
      { subject: 'Math', score: 85 },
      { subject: 'Physics', score: 78 }
    ];

    if (isMongoConnected()) {
      const list = await MarkModel.find();
      if (list.length > 0) {
        let sum = 0;
        list.forEach((m: any) => sum += m.score || 0);
        average = Math.round(sum / list.length);
        subjectPerformance = list.map((m: any) => ({
          subject: m.subject,
          score: m.score || 0
        }));
      }
    } else {
      if (localDb.marks.length > 0) {
        let sum = 0;
        localDb.marks.forEach((m: any) => sum += m.score || 0);
        average = Math.round(sum / localDb.marks.length);
        subjectPerformance = localDb.marks.map((m: any) => ({
          subject: m.subject,
          score: m.score || 0
        }));
      }
    }

    res.json({ average, trend, subjectPerformance });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 8. Notes APIs
api.get('/notes', authenticateToken, async (req: any, res) => {
  try {
    if (isMongoConnected()) {
      const notes = await NoteModel.find({ userId: req.user.id });
      res.json(notes);
    } else {
      res.json(localDb.notes.filter((n: any) => n.userId === req.user.id));
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.post('/notes', authenticateToken, async (req: any, res) => {
  try {
    const note = { id: Date.now().toString(), ...req.body, userId: req.user.id };
    if (isMongoConnected()) {
      await new NoteModel(note).save();
    } else {
      localDb.notes.push(note);
    }
    res.status(201).json(note);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.put('/notes/:id', authenticateToken, async (req, res) => {
  try {
    let updated;
    if (isMongoConnected()) {
      updated = await NoteModel.findOneAndUpdate({ id: req.params.id }, req.body, { new: true });
    } else {
      const index = localDb.notes.findIndex((n: any) => n.id === req.params.id);
      if (index !== -1) {
        localDb.notes[index] = { ...localDb.notes[index], ...req.body };
        updated = localDb.notes[index];
      }
    }

    if (updated) {
      res.json(updated);
    } else {
      res.status(404).json({ message: 'Note not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.delete('/notes/:id', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected()) {
      await NoteModel.deleteOne({ id: req.params.id });
    } else {
      localDb.notes = localDb.notes.filter((n: any) => n.id !== req.params.id);
    }
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 9. Habits APIs
api.get('/habits', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected()) {
      const list = await HabitModel.find({ userId: (req as any).user.id });
      res.json(list);
    } else {
      res.json(localDb.habits.filter((h: any) => h.userId === (req as any).user.id));
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.post('/habits', authenticateToken, async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const isCompleted = req.body.completed || false;
    const habit = {
      id: Date.now().toString(),
      name: req.body.name || '',
      category: req.body.category || 'General',
      detail: req.body.detail || '',
      completed: isCompleted,
      streak: req.body.streak || 0,
      completedDate: isCompleted ? today : '',
      userId: (req as any).user.id,
      createdAt: new Date()
    };
    if (isMongoConnected()) {
      await new HabitModel(habit).save();
    } else {
      localDb.habits.push(habit);
    }
    res.status(201).json(habit);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.patch('/habits/:id/status', authenticateToken, async (req, res) => {
  try {
    let updated;
    const today = new Date().toISOString().split('T')[0];
    if (isMongoConnected()) {
      const habit = await HabitModel.findOne({ id: req.params.id, userId: (req as any).user.id });
      if (habit) {
        const nextCompleted = req.body.completed !== undefined ? req.body.completed : !habit.completed;
        habit.completed = nextCompleted;
        habit.completedDate = nextCompleted ? today : '';
        if (nextCompleted) {
          habit.streak = (habit.streak || 0) + 1;
        } else {
          habit.streak = Math.max(0, (habit.streak || 1) - 1);
        }
        await habit.save();
        updated = habit;
      }
    } else {
      const index = localDb.habits.findIndex((h: any) => h.id === req.params.id && h.userId === (req as any).user.id);
      if (index !== -1) {
        const habit = localDb.habits[index];
        const nextCompleted = req.body.completed !== undefined ? req.body.completed : !habit.completed;
        habit.completed = nextCompleted;
        habit.completedDate = nextCompleted ? today : '';
        if (nextCompleted) {
          habit.streak = (habit.streak || 0) + 1;
        } else {
          habit.streak = Math.max(0, (habit.streak || 1) - 1);
        }
        localDb.habits[index] = habit;
        updated = habit;
      }
    }

    if (updated) {
      res.json(updated);
    } else {
      res.status(404).json({ message: 'Habit not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.delete('/habits/:id', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected()) {
      await HabitModel.deleteOne({ id: req.params.id, userId: (req as any).user.id });
    } else {
      localDb.habits = localDb.habits.filter((h: any) => !(h.id === req.params.id && h.userId === (req as any).user.id));
    }
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 10. Notifications APIs
api.get('/notifications', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected()) {
      const list = await NotificationModel.find();
      res.json(list);
    } else {
      res.json(localDb.notifications);
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.patch('/notifications/:id/read', authenticateToken, async (req, res) => {
  try {
    let updated;
    if (isMongoConnected()) {
      updated = await NotificationModel.findOneAndUpdate({ id: req.params.id }, { read: true }, { new: true });
    } else {
      const notif = localDb.notifications.find(n => n.id === req.params.id);
      if (notif) {
        notif.read = true;
        updated = notif;
      }
    }
    res.json({ success: true, notification: updated });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 12. File APIs
api.post('/files/upload', authenticateToken, async (req, res) => {
  try {
    const file = { id: Date.now().toString(), name: req.body.name || 'Assignment.pdf', url: 'https://example.com/file' };
    if (isMongoConnected()) {
      await new FileModel(file).save();
    } else {
      localDb.files.push(file);
    }
    res.json(file);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.delete('/files/:id', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected()) {
      await FileModel.deleteOne({ id: req.params.id });
    } else {
      localDb.files = localDb.files.filter((f: any) => f.id !== req.params.id);
    }
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 13. Settings APIs
api.get('/settings', authenticateToken, async (req, res) => {
  try {
    let settings;
    if (isMongoConnected()) {
      settings = await SettingsModel.findOne();
      if (!settings) {
        settings = await SettingsModel.create(localDb.settings);
      }
    } else {
      settings = localDb.settings;
    }
    res.json(settings);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

api.put('/settings', authenticateToken, async (req, res) => {
  try {
    let updated;
    if (isMongoConnected()) {
      updated = await SettingsModel.findOneAndUpdate({}, req.body, { upsert: true, new: true });
    } else {
      localDb.settings = { ...localDb.settings, ...req.body };
      updated = localDb.settings;
    }
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 14. Analytics APIs
api.get('/analytics/study-time', authenticateToken, (req, res) => {
  res.json({
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    data: [4, 6, 2, 8, 5, 10, 3]
  });
});

api.get('/analytics/productivity', authenticateToken, (req, res) => {
  res.json({ score: 85, trend: '+5%' });
});

app.use('/api/v1', api);

// --- VITE MIDDLEWARE ---
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`API base endpoints at /api/v1`);
    console.log(`MongoDB storage status: ${isMongoConnected() ? 'Online' : 'Offline (In-memory Fallback active)'}`);
  });
}

startServer();
