import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { UserProvider } from './context/UserContext';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Timetable from './pages/Timetable';
import Tasks from './pages/Tasks';
import Performance from './pages/Performance';
import AiAssistant from './pages/AiAssistant';
import AiSummarizer from './pages/AiSummarizer';
import QuizGenerator from './pages/QuizGenerator';
import StudyPlanner from './pages/StudyPlanner';
import HabitTracker from './pages/HabitTracker';
import FocusTimer from './pages/FocusTimer';
import Notifications from './pages/Notifications';
import Profile from './pages/Profile';
import Settings from './pages/Settings';
import Antigravity from './pages/Antigravity';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return localStorage.getItem('is_authenticated') === 'true';
  });

  useEffect(() => {
    const checkNotification = () => {
      const now = new Date();
      if (now.getHours() === 22 && now.getMinutes() === 0) {
        if (!("Notification" in window)) {
          alert("Reminder: It's 10:00 PM! Time to review your goals for tomorrow.");
        } else if (Notification.permission === "granted") {
          new Notification("10:00 PM Reminder", { body: "Time to review your goals for tomorrow." });
        } else if (Notification.permission !== "denied") {
          Notification.requestPermission().then(permission => {
            if (permission === "granted") {
              new Notification("10:00 PM Reminder", { body: "Time to review your goals for tomorrow." });
            } else {
              alert("Reminder: It's 10:00 PM! Time to review your goals for tomorrow.");
            }
          });
        }
      }
    };

    const interval = setInterval(checkNotification, 60000); // Check every minute
    return () => clearInterval(interval);
  }, []);

  const handleLogin = () => {
    setIsAuthenticated(true);
    localStorage.setItem('is_authenticated', 'true');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('is_authenticated');
  };

  return (
    <ThemeProvider>
      <UserProvider>
        <BrowserRouter>
          <Routes>
            {/* Public Routes */}
            <Route 
              path="/login" 
              element={!isAuthenticated ? <Login onLogin={handleLogin} /> : <Navigate to="/" replace />} 
            />
            <Route 
              path="/signup" 
              element={!isAuthenticated ? <Signup onLogin={handleLogin} /> : <Navigate to="/" replace />} 
            />

            {/* Protected Routes */}
            <Route element={<Layout isAuthenticated={isAuthenticated} onLogout={handleLogout} />}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/timetable" element={<Timetable />} />
              <Route path="/tasks" element={<Tasks />} />
              <Route path="/performance" element={<Performance />} />
              <Route path="/ai-assistant" element={<AiAssistant />} />
              <Route path="/summarizer" element={<AiSummarizer />} />
              <Route path="/quiz" element={<QuizGenerator />} />
              <Route path="/planner" element={<StudyPlanner />} />
              <Route path="/habits" element={<HabitTracker />} />
              <Route path="/focus" element={<FocusTimer />} />
              <Route path="/notifications" element={<Notifications />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/antigravity" element={<Antigravity />} />
            </Route>

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </UserProvider>
    </ThemeProvider>
  );
}
