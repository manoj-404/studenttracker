import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import Navigation from './Navigation';

export default function Layout({ isAuthenticated, onLogout }: { isAuthenticated: boolean; onLogout: () => void }) {
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="flex flex-col md:flex-row h-screen bg-gray-50/50 dark:bg-gray-950 transition-colors duration-300 overflow-hidden">
      <Navigation onLogout={onLogout} />
      <main className="flex-1 pb-20 md:pb-0 overflow-y-auto">
        <div className="max-w-6xl mx-auto p-4 md:p-8 lg:p-12 dark:text-gray-100">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
