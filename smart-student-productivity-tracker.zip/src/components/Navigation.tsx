import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  CalendarDays, 
  CheckSquare, 
  Timer,
  BarChart3, 
  UserCircle,
  LogOut,
  GraduationCap,
  Sparkles,
  FileText,
  Brain,
  Calendar,
  Zap,
  Bell,
  Settings,
  Atom
} from 'lucide-react';
import { cn } from '../lib/utils';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
  { icon: CalendarDays, label: 'Timetable', path: '/timetable' },
  { icon: CheckSquare, label: 'Tasks', path: '/tasks' },
  { icon: Timer, label: 'Focus & Break', path: '/focus' },
  { icon: Zap, label: 'Habits', path: '/habits' },
  { icon: Bell, label: 'Alerts', path: '/notifications' },
  { icon: BarChart3, label: 'Performance', path: '/performance' },
];

const aiItems = [
  { icon: Sparkles, label: 'AI Tutor', path: '/ai-assistant' },
  { icon: FileText, label: 'Summarizer', path: '/summarizer' },
  { icon: Brain, label: 'Quiz Gen', path: '/quiz' },
  { icon: Calendar, label: 'Study Plan', path: '/planner' },
];

const userItems = [
  { icon: UserCircle, label: 'Profile', path: '/profile' },
  { icon: Settings, label: 'Settings', path: '/settings' },
  { icon: Atom, label: 'Antigravity Lab', path: '/antigravity' },
];

export default function Navigation({ onLogout }: { onLogout?: () => void }) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white/80 dark:bg-gray-950/80 backdrop-blur-md border-t border-gray-200 dark:border-gray-800 px-4 py-2 md:sticky md:top-0 md:w-64 md:border-r md:border-t-0 md:bg-white md:dark:bg-gray-950 md:px-3 md:py-6 h-auto md:h-screen flex flex-row md:flex-col justify-around md:justify-start gap-1 overflow-x-auto md:overflow-y-auto transition-colors duration-300">
      <div className="hidden md:flex items-center gap-3 px-3 mb-10">
        <div className="bg-indigo-600 p-2 rounded-xl">
          <GraduationCap className="text-white w-6 h-6" />
        </div>
        <span className="font-bold text-lg leading-tight tracking-tighter text-gray-900 dark:text-white font-sans">Smart Student Tracker</span>
      </div>

      <div className="flex md:flex-col items-center md:items-stretch justify-around w-full gap-1">
        <div className="hidden md:block px-3 mb-2">
          <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Core</p>
        </div>
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => cn(
              "flex flex-col md:flex-row items-center gap-1 md:gap-3 px-3 py-2 rounded-xl transition-all duration-200 group text-xs md:text-sm font-medium",
              isActive 
                ? "text-indigo-600 bg-indigo-50 dark:bg-indigo-900/20 font-semibold" 
                : "text-gray-500 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-900"
            )}
          >
            <item.icon className={cn("w-5 h-5 transition-transform group-hover:scale-110")} />
            <span>{item.label}</span>
          </NavLink>
        ))}

        <div className="hidden md:block px-3 mt-6 mb-2">
          <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">AI Power</p>
        </div>
        <div className="flex md:flex-col items-center md:items-stretch justify-around gap-1">
          {aiItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => cn(
                "flex flex-col md:flex-row items-center gap-1 md:gap-3 px-3 py-2 rounded-xl transition-all duration-200 group text-xs md:text-sm font-medium",
                isActive 
                  ? "text-indigo-600 bg-indigo-50 dark:bg-indigo-900/20 font-semibold" 
                  : "text-gray-500 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-900"
              )}
            >
              <item.icon className={cn("w-5 h-5 transition-transform group-hover:scale-110")} />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </div>

        <div className="hidden md:block px-3 mt-6 mb-2">
          <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Account</p>
        </div>
        <div className="flex md:flex-col items-center md:items-stretch justify-around gap-1">
          {userItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => cn(
                "flex flex-col md:flex-row items-center gap-1 md:gap-3 px-3 py-2 rounded-xl transition-all duration-200 group text-xs md:text-sm font-medium",
                isActive 
                  ? "text-indigo-600 bg-indigo-50 dark:bg-indigo-900/20 font-semibold" 
                  : "text-gray-500 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-900"
              )}
            >
              <item.icon className={cn("w-5 h-5 transition-transform group-hover:scale-110")} />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </div>
      </div>

      <div className="hidden md:block mt-auto pt-6 border-t border-gray-100 dark:border-gray-800">
        <button 
          onClick={onLogout}
          className="flex items-center gap-3 px-3 py-2 rounded-xl w-full text-gray-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors text-sm font-medium"
        >
          <LogOut className="w-5 h-5" />
          <span>Sign Out</span>
        </button>
      </div>
    </nav>
  );
}
