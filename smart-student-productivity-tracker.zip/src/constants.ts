import { Task, AttendanceRecord, TimetableEntry, PerformanceRecord, User } from './types';

export const DUMMY_USER: User = {
  name: "Manoj Kumar",
  email: "manoj@gmail.com",
  course: "B.E Computer Science",
  year: "2nd Year",
  cgpa: 8.83,
  rollNo: "22CSE001",
  section: "C",
  campus: "Main Tech Campus",
  profilePic: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=400&h=400&auto=format&fit=crop",
  arrears: 0
};

export const DUMMY_TASKS: Task[] = [
  { id: '1', title: "FET Assignment", dueDate: "Tomorrow", status: 'Pending' },
  { id: '2', title: "DSA Record", dueDate: "In 2 days", status: 'Pending' },
  { id: '3', title: "Complete Java Project", dueDate: "May 15", status: 'Pending' },
  { id: '4', title: "Study Unit 3 AJP", dueDate: "Yesterday", status: 'Done' },
];

export const DUMMY_ATTENDANCE: AttendanceRecord[] = [
  { subject: "Math", attended: 18, total: 22 },
  { subject: "DSA", attended: 15, total: 22 },
  { subject: "FET", attended: 20, total: 22 },
  { subject: "Tamil", attended: 12, total: 22 },
];

export const DUMMY_TIMETABLE: TimetableEntry[] = [
  {
    day: "MONDAY",
    slots: [
      { hour: 1, subject: "MATHS", color: "bg-orange-500" },
      { hour: 2, subject: "DSA", color: "bg-orange-600" },
      { hour: 3, subject: "WEB", color: "bg-orange-500" },
      { hour: 4, subject: "AJP", span: 2, color: "bg-orange-600" },
      { hour: 6, subject: "MATHS", color: "bg-orange-500" },
      { hour: 7, subject: "DSA", color: "bg-orange-600" },
      { hour: 8, subject: "WEB", span: 2, color: "bg-orange-600" },
    ]
  },
  {
    day: "TUESDAY",
    slots: [
      { hour: 1, subject: "WEB", span: 2, color: "bg-orange-500" },
      { hour: 3, subject: "AJP", color: "bg-orange-600" },
      { hour: 4, subject: "MATHS", span: 2, color: "bg-orange-500" },
      { hour: 6, subject: "DSA", color: "bg-orange-500" },
      { hour: 7, subject: "AJP", color: "bg-orange-600" },
      { hour: 8, subject: "MATHS", span: 2, color: "bg-orange-500" },
    ]
  },
  {
    day: "WEDNESDAY",
    slots: [
      { hour: 1, subject: "DSA", span: 2, color: "bg-orange-500" },
      { hour: 3, subject: "WEB", color: "bg-orange-600" },
      { hour: 4, subject: "AJP", span: 2, color: "bg-orange-500" },
      { hour: 6, subject: "MATHS", color: "bg-orange-600" },
      { hour: 7, subject: "DSA", color: "bg-orange-500" }, 
      { hour: 8, subject: "WEB", span: 2, color: "bg-orange-500" },
    ]
  },
  {
    day: "THURSDAY",
    slots: [
      { hour: 1, subject: "AJP", span: 2, color: "bg-orange-600" },
      { hour: 3, subject: "MATHS", color: "bg-orange-500" },
      { hour: 4, subject: "DSA", span: 2, color: "bg-orange-600" },
      { hour: 6, subject: "WEB", span: 2, color: "bg-orange-500" },
      { hour: 8, subject: "AJP", color: "bg-orange-600" },
      { hour: 9, subject: "MATHS", color: "bg-orange-500" },
    ]
  },
  {
    day: "FRIDAY",
    slots: [
      { hour: 1, subject: "MATHS", span: 2, color: "bg-orange-500" },
      { hour: 3, subject: "DSA", color: "bg-orange-600" },
      { hour: 4, subject: "WEB", span: 2, color: "bg-orange-500" },
      { hour: 6, subject: "AJP", span: 2, color: "bg-orange-600" },
      { hour: 8, subject: "DSA", color: "bg-orange-500" },
      { hour: 9, subject: "WEB", color: "bg-orange-600" },
    ]
  },
  {
    day: "SATURDAY",
    isDayOrder: true,
    slots: []
  },
];

export const DUMMY_PERFORMANCE: PerformanceRecord[] = [
  { subject: "MATHS", test1: 75, test2: 80, semResult: 85, final: 78 },
  { subject: "DSA", test1: 60, test2: 65, semResult: 70, final: 62 },
  { subject: "WEB", test1: 85, test2: 88, semResult: 92, final: 87 },
  { subject: "AJP", test1: 45, test2: 50, semResult: 55, final: 48 },
];

export const AI_SUGGESTIONS = [
  "Focus on AJP, your score dropped last test",
  "Prepare for Math internals appearing next week",
  "Great job on FET, keep up the 90% attendance!"
];

export const DUMMY_NOTIFICATIONS = [
  { id: '1', title: 'Assignment due tomorrow', description: 'FET Assignment - Submission deadline: May 9th', type: 'warning', time: '2h ago' },
  { id: '2', title: 'Attendance alert', description: 'Tamil attendance dropped below 75%', type: 'error', time: '5h ago' },
  { id: '3', title: 'Exam reminder', description: 'Math internals starting in 5 days', type: 'info', time: '1d ago' },
  { id: '4', title: 'Task Completed', description: 'Study Unit 3 AJP marked as done', type: 'success', time: '2d ago' },
];
