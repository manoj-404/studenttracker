import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback, useMemo } from 'react';
import { User } from '../types';
import { DUMMY_USER } from '../constants';

interface UserContextType {
  user: User;
  updateUser: (data: Partial<User>) => void;
  updateCgpa: (cgpa: number) => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User>(() => {
    const saved = localStorage.getItem('user_data');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        // Ensure new properties from DUMMY_USER are present even in old saved data
        return { ...DUMMY_USER, ...data };
      } catch (e) {
        console.error("Failed to parse user data", e);
        return DUMMY_USER;
      }
    }
    return DUMMY_USER;
  });

  useEffect(() => {
    localStorage.setItem('user_data', JSON.stringify(user));
  }, [user]);

  const updateUser = useCallback((data: Partial<User>) => {
    setUser(prev => ({ ...prev, ...data }));
  }, []);

  const updateCgpa = useCallback((cgpa: number) => {
    setUser(prev => {
      if (prev.cgpa === cgpa) return prev;
      return { ...prev, cgpa };
    });
  }, []);

  const contextValue = useMemo(() => ({
    user,
    updateUser,
    updateCgpa
  }), [user, updateUser, updateCgpa]);

  return (
    <UserContext.Provider value={contextValue}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}
