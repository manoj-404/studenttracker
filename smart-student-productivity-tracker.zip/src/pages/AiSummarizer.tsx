import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { FileText, Wand2, Loader2, Copy, Check, Upload, Trash2 } from 'lucide-react';
import { summarizeText } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';
import * as pdfjs from 'pdfjs-dist';

// Configure PDF.js worker
pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

export default function AiSummarizer() {
  const [input, setInput] = useState('');
  const [summary, setSummary] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSummarize = async (textToSummarize?: string) => {
    const targetText = textToSummarize || input;
    if (!targetText.trim() || isLoading) return;

    setIsLoading(true);
    setSummary('');
    try {
      const result = await summarizeText(targetText);
      setSummary(result || '');
    } catch (error) {
      console.error('Summarization failed:', error);
      setSummary('Failed to generate summary.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setIsExtracting(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const loadingTask = pdfjs.getDocument({ 
        data: arrayBuffer,
      });
      
      const pdf = await loadingTask.promise;
      let fullText = '';

      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items
          .map((item: any) => item.str)
          .join(' ');
        fullText += pageText + '\n\n';
      }

      const extractedText = fullText.trim();
      setInput(extractedText);
      
      // Auto-summarize
      if (extractedText) {
        await handleSummarize(extractedText);
      }
    } catch (error) {
      console.error('Error parsing PDF:', error);
      alert('Failed to extract text from PDF.');
      setFileName(null);
    } finally {
      setIsExtracting(false);
      if (e.target) e.target.value = '';
    }
  };

  const handleClear = () => {
    setInput('');
    setSummary('');
    setFileName(null);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(summary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight">AI Notes Summarizer</h1>
          <p className="text-gray-500 dark:text-gray-400 font-medium tracking-tight">Turn long, complex notes into short, readable summaries.</p>
        </div>
        
        <div className="flex gap-2">
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileUpload}
            accept=".pdf" 
            className="hidden" 
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={isExtracting}
            className="flex items-center gap-2 px-6 py-3 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl text-xs font-black uppercase tracking-widest text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-all shadow-lg active:scale-95 disabled:opacity-50"
          >
            {isExtracting ? (
              <Loader2 className="w-4 h-4 animate-spin text-indigo-500" />
            ) : (
              <Upload className="w-4 h-4 text-indigo-500" />
            )}
            {isExtracting ? 'Extracting...' : 'Import PDF'}
          </button>
          
          {input && (
            <button 
              onClick={handleClear}
              className="p-3 text-rose-500 bg-rose-50 dark:bg-rose-900/10 rounded-2xl hover:bg-rose-100 transition-all active:scale-95 flex items-center gap-2"
              title="Clear all"
            >
              <Trash2 className="w-4 h-4" />
              <span className="text-[10px] font-black uppercase tracking-widest md:block hidden">Clear</span>
            </button>
          )}
        </div>
      </header>

      <div className="grid lg:grid-cols-2 gap-8 items-start">
        {/* Input section */}
        <section className="bg-white dark:bg-gray-900 p-6 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-xl space-y-4 transition-colors">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
              <FileText className="w-5 h-5" />
              <h2 className="font-bold text-sm uppercase tracking-widest">Input Notes</h2>
            </div>
            {fileName && (
              <div className="flex items-center gap-2 px-3 py-1 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-full text-[10px] font-bold">
                <Check className="w-3 h-3" />
                {fileName}
              </div>
            )}
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Paste your notes here or upload a PDF..."
            className="w-full h-[400px] p-6 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all font-medium text-sm leading-relaxed dark:text-gray-100 resize-none"
          />
          <button
            onClick={() => handleSummarize()}
            disabled={!input.trim() || isLoading}
            className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-indigo-700 transition-all active:scale-[0.98] disabled:opacity-50 shadow-xl shadow-indigo-100 dark:shadow-none"
          >
            {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Wand2 className="w-5 h-5" />}
            Summarize Now
          </button>
        </section>

        {/* Output section */}
        <section className="bg-white dark:bg-gray-900 p-6 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-xl min-h-[500px] flex flex-col transition-colors">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
              <div className="p-1.5 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg text-emerald-600">
                <Check className="w-4 h-4" />
              </div>
              <h2 className="font-bold text-sm uppercase tracking-widest">AI Summary</h2>
            </div>
            {summary && (
              <button 
                onClick={copyToClipboard}
                className="p-2 text-gray-400 dark:text-gray-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-all"
                title="Copy to clipboard"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              </button>
            )}
          </div>
          <div className="flex-1 p-8 bg-emerald-50/10 dark:bg-emerald-900/5 rounded-2xl border border-emerald-100/30 dark:border-emerald-800/20 overflow-y-auto">
            {isLoading ? (
              <div className="h-full flex flex-col items-center justify-center text-gray-400 space-y-4">
                <Loader2 className="w-10 h-10 animate-spin text-indigo-200" />
                <p className="text-sm font-bold uppercase tracking-widest text-indigo-300">Distilling Content...</p>
              </div>
            ) : summary ? (
              <div className="prose prose-sm prose-emerald dark:prose-invert max-w-none prose-headings:font-black prose-p:font-medium prose-li:font-medium">
                <ReactMarkdown>{summary}</ReactMarkdown>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-gray-300 dark:text-gray-600 italic text-sm text-center px-10">
                <FileText className="w-12 h-12 mb-4 opacity-10" />
                Your AI-generated summary will appear here after you provide your notes.
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
