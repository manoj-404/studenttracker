import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Atom, 
  Wind, 
  RotateCcw, 
  Zap, 
  Play, 
  Pause, 
  Plus, 
  Trash2, 
  Sparkles, 
  Timer, 
  GraduationCap, 
  CheckCircle2, 
  Check, 
  Info,
  Compass,
  ArrowRight,
  Flame
} from 'lucide-react';
import { DUMMY_TASKS, DUMMY_ATTENDANCE } from '../constants';
import { useUser } from '../context/UserContext';
import { cn } from '../lib/utils';
import { Task } from '../types';

interface PhysicalItem {
  id: string;
  type: string;
  title: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  angle: number;
  va: number; // angular velocity
  isDragging: boolean;
  colorClass: string;
}

interface Asteroid {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
}

export default function Antigravity() {
  const { user } = useUser();
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Physics modes
  const [gravityMode, setGravityMode] = useState<'antigravity' | 'gravity' | 'zerogravity'>('antigravity');
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);
  const [wind, setWind] = useState<'none' | 'left' | 'right'>('none');
  const [chaosMode, setChaosMode] = useState<boolean>(false);
  const [asteroids, setAsteroids] = useState<Asteroid[]>([]);

  // Local interactive widget states running inside the floaters
  const [tasks, setTasks] = useState<Task[]>(DUMMY_TASKS);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  
  const [timerSeconds, setTimerSeconds] = useState(1500); // 25:00
  const [timerActive, setTimerActive] = useState(false);
  
  const [notes, setNotes] = useState('Type your high-orbit thoughts here...');

  // Floating nodes list
  const [items, setItems] = useState<PhysicalItem[]>([
    {
      id: 'instructions',
      type: 'instructions',
      title: '🚀 Antigravity Controls',
      x: 30,
      y: 40,
      vx: 0.5,
      vy: -0.5,
      width: 280,
      height: 220,
      angle: 0.05,
      va: 0.002,
      isDragging: false,
      colorClass: 'bg-indigo-600 text-white'
    },
    {
      id: 'tasks',
      type: 'tasks',
      title: '📋 Interactive Missions',
      x: 340,
      y: 80,
      vx: -0.4,
      vy: 0.6,
      width: 320,
      height: 280,
      angle: -0.04,
      va: -0.001,
      isDragging: false,
      colorClass: 'bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 shadow-xl'
    },
    {
      id: 'pomodoro',
      type: 'pomodoro',
      title: '⏱️ Hover Focus Clock',
      x: 80,
      y: 320,
      vx: 0.7,
      vy: -0.3,
      width: 240,
      height: 200,
      angle: 0.02,
      va: 0.004,
      isDragging: false,
      colorClass: 'bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 shadow-xl'
    },
    {
      id: 'attendance',
      type: 'attendance',
      title: '📊 Attendance Dashboard',
      x: 700,
      y: 120,
      vx: -0.6,
      vy: -0.5,
      width: 250,
      height: 240,
      angle: 0.08,
      va: -0.003,
      isDragging: false,
      colorClass: 'bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 shadow-xl'
    },
    {
      id: 'scratchpad',
      type: 'scratchpad',
      title: '✏️ Zero-G Scratchpad',
      x: 400,
      y: 380,
      vx: 0.3,
      vy: 0.4,
      width: 280,
      height: 200,
      angle: -0.06,
      va: 0.001,
      isDragging: false,
      colorClass: 'bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 shadow-xl'
    },
    {
      id: 'profile',
      type: 'profile',
      title: '🎓 Student Astronaut',
      x: 720,
      y: 400,
      vx: 0.4,
      vy: -0.6,
      width: 260,
      height: 180,
      angle: -0.02,
      va: 0.002,
      isDragging: false,
      colorClass: 'bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 shadow-xl'
    }
  ]);

  // Dragging refs
  const dragInfoRef = useRef<{
    itemId: string | null;
    startX: number;
    startY: number;
    lastMouseX: number;
    lastMouseY: number;
    lastTime: number;
  }>({
    itemId: null,
    startX: 0,
    startY: 0,
    lastMouseX: 0,
    lastMouseY: 0,
    lastTime: 0
  });

  // Focus Timer intervals
  useEffect(() => {
    let interval: any = null;
    if (timerActive && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds(s => s - 1);
      }, 1000);
    } else if (timerSeconds === 0) {
      setTimerActive(false);
    }
    return () => clearInterval(interval);
  }, [timerActive, timerSeconds]);

  // Handle simple task operations inside the task widget
  const handleToggleTaskStatus = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, status: t.status === 'Pending' ? 'Done' : 'Pending' } : t));
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    const newTask: Task = {
      id: Date.now().toString(),
      title: newTaskTitle,
      dueDate: 'Orbit',
      status: 'Pending'
    };
    setTasks(prev => [newTask, ...prev]);
    setNewTaskTitle('');
  };

  const handleDeleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  // Main physics loop
  useEffect(() => {
    let animationFrameId: number;
    
    const updatePhysics = () => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const containerWidth = rect.width;
      const containerHeight = rect.height;

      // Update Floating Widgets
      setItems(prevItems => {
        return prevItems.map(item => {
          if (item.isDragging) {
            return item; // Position is locked to coordinates updated by drag handler
          }

          let vx = item.vx;
          let vy = item.vy;
          let va = item.va;

          // Apply forces based on settings
          if (gravityMode === 'gravity') {
            vy += 0.25; // standard gravitational pull downward
          } else if (gravityMode === 'antigravity') {
            vy -= 0.12; // upward draft
          } else if (gravityMode === 'zerogravity') {
            // zero gravity Brownian-like drift
            vx += (Math.random() - 0.5) * 0.05;
            vy += (Math.random() - 0.5) * 0.05;
          }

          // Apply Wind forces
          if (wind === 'left') {
            vx -= 0.08;
          } else if (wind === 'right') {
            vx += 0.08;
          }

          // Apply speeds and air friction damping (drag)
          vx *= 0.985;
          vy *= 0.985;
          va *= 0.97; // angular friction

          // Clip to sensible max speed
          const maxSpeed = 15;
          const currentSpeed = Math.sqrt(vx * vx + vy * vy);
          if (currentSpeed > maxSpeed) {
            vx = (vx / currentSpeed) * maxSpeed;
            vy = (vy / currentSpeed) * maxSpeed;
          }

          let x = item.x + vx * speedMultiplier;
          let y = item.y + vy * speedMultiplier;
          let angle = item.angle + va * speedMultiplier;

          // Bounciness factor
          const bounce = 0.75;

          // Collision boundaries with screen walls
          if (x < 0) {
            x = 0;
            vx = -vx * bounce;
            va = (Math.random() - 0.5) * 0.02 - vy * 0.01;
          } else if (x + item.width > containerWidth) {
            x = containerWidth - item.width;
            vx = -vx * bounce;
            va = (Math.random() - 0.5) * 0.02 + vy * 0.01;
          }

          if (y < 0) {
            y = 0;
            vy = -vy * bounce;
            va = (Math.random() - 0.5) * 0.02 + vx * 0.01;
          } else if (y + item.height > containerHeight) {
            y = containerHeight - item.height;
            vy = -vy * bounce;
            va = (Math.random() - 0.5) * 0.02 - vx * 0.01;
          }

          return {
            ...item,
            x,
            y,
            vx,
            vy,
            angle,
            va
          };
        });
      });

      // Update Chaos Asteroids
      setAsteroids(prevAsteroids => {
        return prevAsteroids.map(ast => {
          let vx = ast.vx;
          let vy = ast.vy;

          if (gravityMode === 'gravity') {
            vy += 0.2;
          } else if (gravityMode === 'antigravity') {
            vy -= 0.08;
          }

          vx *= 0.995;
          vy *= 0.995;

          let x = ast.x + vx * speedMultiplier;
          let y = ast.y + vy * speedMultiplier;

          const radius = ast.radius;

          if (x - radius < 0) {
            x = radius;
            vx = -vx * 0.9;
          } else if (x + radius > containerWidth) {
            x = containerWidth - radius;
            vx = -vx * 0.9;
          }

          if (y - radius < 0) {
            y = radius;
            vy = -vy * 0.9;
          } else if (y + radius > containerHeight) {
            y = containerHeight - radius;
            vy = -vy * 0.9;
          }

          return { ...ast, x, y, vx, vy };
        });
      });

      animationFrameId = requestAnimationFrame(updatePhysics);
    };

    animationFrameId = requestAnimationFrame(updatePhysics);
    return () => cancelAnimationFrame(animationFrameId);
  }, [gravityMode, wind, speedMultiplier]);

  // Mouse drag events
  const handlePointerDown = (id: string, e: React.PointerEvent) => {
    e.preventDefault();
    const item = items.find(it => it.id === id);
    if (!item) return;

    // Put item on top by changing item order if we want, or just update dragging state
    setItems(prev => prev.map(it => it.id === id ? { ...it, isDragging: true, vx: 0, vy: 0, va: 0 } : it));

    dragInfoRef.current = {
      itemId: id,
      startX: e.clientX - item.x,
      startY: e.clientY - item.y,
      lastMouseX: e.clientX,
      lastMouseY: e.clientY,
      lastTime: Date.now()
    };

    if (containerRef.current) {
      containerRef.current.setPointerCapture(e.pointerId);
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    const { itemId } = dragInfoRef.current;
    if (!itemId) return;

    setItems(prev => prev.map(item => {
      if (item.id !== itemId) return item;

      const newX = e.clientX - dragInfoRef.current.startX;
      const newY = e.clientY - dragInfoRef.current.startY;

      // Track time and mouse displacement to calculate throw velocities
      const now = Date.now();
      const dt = now - dragInfoRef.current.lastTime;
      let vx = item.vx;
      let vy = item.vy;

      if (dt > 0) {
        // Calculate raw velocity
        const dx = e.clientX - dragInfoRef.current.lastMouseX;
        const dy = e.clientY - dragInfoRef.current.lastMouseY;
        
        // Slightly smooth velocities
        vx = (dx / dt) * 10; 
        vy = (dy / dt) * 10;
      }

      dragInfoRef.current.lastMouseX = e.clientX;
      dragInfoRef.current.lastMouseY = e.clientY;
      dragInfoRef.current.lastTime = now;

      return {
        ...item,
        x: newX,
        y: newY,
        vx,
        vy,
        angle: vx * 0.015, // angle slants slightly with momentum
        va: vx * 0.005
      };
    }));
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    const { itemId } = dragInfoRef.current;
    if (!itemId) return;

    setItems(prev => prev.map(it => it.id === itemId ? { ...it, isDragging: false } : it));
    dragInfoRef.current.itemId = null;

    if (containerRef.current) {
      containerRef.current.releasePointerCapture(e.pointerId);
    }
  };

  // Shockwave Explosion pushing all items away
  const triggerShockwave = (clientX?: number, clientY?: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    
    // Choose center of screen or mouse location for epicenter
    const centerX = clientX ? clientX - rect.left : rect.width / 2;
    const centerY = clientY ? clientY - rect.top : rect.height / 2;

    setItems(prev => prev.map(item => {
      // Find item center
      const itemCenterX = item.x + item.width / 2;
      const itemCenterY = item.y + item.height / 2;

      const dx = itemCenterX - centerX;
      const dy = itemCenterY - centerY;
      const distance = Math.sqrt(dx * dx + dy * dy) || 1;

      // Force falls off with distance
      const forcePower = Math.max(5, 500 / (distance * 0.05 + 10));

      return {
        ...item,
        vx: item.vx + (dx / distance) * forcePower,
        vy: item.vy + (dy / distance) * forcePower,
        va: item.va + (Math.random() - 0.5) * 0.1
      };
    }));

    // Repel Chaos Asteroids
    setAsteroids(prev => prev.map(ast => {
      const dx = ast.x - centerX;
      const dy = ast.y - centerY;
      const distance = Math.sqrt(dx * dx + dy * dy) || 1;
      const forcePower = Math.max(8, 400 / (distance * 0.04 + 8));

      return {
        ...ast,
        vx: ast.vx + (dx / distance) * forcePower,
        vy: ast.vy + (dy / distance) * forcePower
      };
    }));
  };

  // Chaos Asteroids Spawning
  const handleToggleChaosMode = () => {
    if (!chaosMode) {
      // Spawn standard cosmic asteroids
      const newAsteroids: Asteroid[] = [];
      const colors = ['#f59e0b', '#dc2626', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899'];
      for (let i = 0; i < 12; i++) {
        newAsteroids.push({
          id: `ast-${i}`,
          x: Math.random() * 500 + 100,
          y: Math.random() * 300 + 100,
          vx: (Math.random() - 0.5) * 10,
          vy: (Math.random() - 0.5) * 10,
          radius: Math.random() * 15 + 10,
          color: colors[i % colors.length]
        });
      }
      setAsteroids(newAsteroids);
    } else {
      setAsteroids([]);
    }
    setChaosMode(!chaosMode);
  };

  // Reset original locations and state
  const handleResetDimensions = () => {
    setGravityMode('antigravity');
    setSpeedMultiplier(1);
    setWind('none');
    setAsteroids([]);
    setChaosMode(false);
    
    setItems([
      {
        id: 'instructions',
        type: 'instructions',
        title: '🚀 Antigravity Controls',
        x: 30,
        y: 40,
        vx: 0.5,
        vy: -0.5,
        width: 280,
        height: 220,
        angle: 0.05,
        va: 0.002,
        isDragging: false,
        colorClass: 'bg-indigo-600 text-white shadow-2xl'
      },
      {
        id: 'tasks',
        type: 'tasks',
        title: '📋 Interactive Missions',
        x: 340,
        y: 80,
        vx: -0.4,
        vy: 0.6,
        width: 320,
        height: 280,
        angle: -0.04,
        va: -0.001,
        isDragging: false,
        colorClass: 'bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 shadow-xl'
      },
      {
        id: 'pomodoro',
        type: 'pomodoro',
        title: '⏱️ Hover Focus Clock',
        x: 80,
        y: 320,
        vx: 0.7,
        vy: -0.3,
        width: 240,
        height: 200,
        angle: 0.02,
        va: 0.004,
        isDragging: false,
        colorClass: 'bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 shadow-xl'
      },
      {
        id: 'attendance',
        type: 'attendance',
        title: '📊 Attendance Dashboard',
        x: 700,
        y: 120,
        vx: -0.6,
        vy: -0.5,
        width: 250,
        height: 240,
        angle: 0.08,
        va: -0.003,
        isDragging: false,
        colorClass: 'bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 shadow-xl'
      },
      {
        id: 'scratchpad',
        type: 'scratchpad',
        title: '✏️ Zero-G Scratchpad',
        x: 400,
        y: 380,
        vx: 0.3,
        vy: 0.4,
        width: 280,
        height: 200,
        angle: -0.06,
        va: 0.001,
        isDragging: false,
        colorClass: 'bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 shadow-xl'
      },
      {
        id: 'profile',
        type: 'profile',
        title: '🎓 Student Astronaut',
        x: 720,
        y: 400,
        vx: 0.4,
        vy: -0.6,
        width: 260,
        height: 180,
        angle: -0.02,
        va: 0.002,
        isDragging: false,
        colorClass: 'bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 shadow-xl'
      }
    ]);
  };

  // Convert timer values to formatting helpers
  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleContainerClick = (e: React.MouseEvent) => {
    // Only trigger if clicking empty background area, not actual cards
    if (e.target === containerRef.current) {
      triggerShockwave(e.clientX, e.clientY);
    }
  };

  return (
    <div className="flex flex-col h-screen -m-4 md:-m-8 lg:-m-12 select-none overflow-hidden">
      {/* Dynamic Controls Header */}
      <div className="bg-white/90 dark:bg-gray-900/90 border-b border-gray-100 dark:border-gray-800 p-4 shrink-0 z-10 backdrop-blur">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Compass className="w-5 h-5 text-indigo-600 dark:text-indigo-400 animate-spin-slow" />
              <h1 className="text-xl font-black text-gray-900 dark:text-white tracking-tight">
                Google Antigravity Lab
              </h1>
            </div>
            <p className="text-xs text-gray-400 mt-0.5">
              Live physics simulation environment for {user.name}'s dashboard. Catch and sling widgets!
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Gravity modes */}
            <div className="bg-gray-100 dark:bg-gray-800 p-0.5 rounded-xl flex items-center gap-0.5 border border-gray-100 dark:border-gray-700">
              <button 
                onClick={() => setGravityMode('antigravity')}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-xs font-semibold transition-all",
                  gravityMode === 'antigravity' 
                    ? "bg-indigo-600 text-white shadow-sm" 
                    : "text-gray-500 hover:text-gray-900 dark:hover:text-white"
                )}
              >
                Zero-G Float
              </button>
              <button 
                onClick={() => setGravityMode('gravity')}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-xs font-semibold transition-all",
                  gravityMode === 'gravity' 
                    ? "bg-indigo-600 text-white shadow-sm" 
                    : "text-gray-500 hover:text-gray-900 dark:hover:text-white"
                )}
              >
                Earth Gravity
              </button>
              <button 
                onClick={() => setGravityMode('zerogravity')}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-xs font-semibold transition-all",
                  gravityMode === 'zerogravity' 
                    ? "bg-indigo-600 text-white shadow-sm" 
                    : "text-gray-500 hover:text-gray-900 dark:hover:text-white"
                )}
              >
                Free Drift
              </button>
            </div>

            {/* Shockwave & Cosmic mode */}
            <button 
              onClick={() => triggerShockwave()}
              className="px-3 py-2 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 rounded-xl text-xs font-bold transition-all border border-indigo-100 dark:border-indigo-900/50 flex items-center gap-1.5"
            >
              <Atom className="w-3.5 h-3.5" />
              Pulse Wave
            </button>

            <button 
              onClick={handleToggleChaosMode}
              className={cn(
                "px-3 py-2 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5",
                chaosMode 
                  ? "bg-amber-500 text-white border-amber-500" 
                  : "bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-700"
              )}
            >
              <Flame className={cn("w-3.5 h-3.5", chaosMode && "animate-pulse")} />
              Asteroids
            </button>

            {/* Wind controller */}
            <div className="bg-gray-100 dark:bg-gray-800 p-0.5 rounded-xl flex items-center gap-0.5 border border-gray-100 dark:border-gray-700">
              <button 
                onClick={() => setWind(w => w === 'left' ? 'none' : 'left')}
                className={cn(
                  "p-1.5 rounded-lg text-xs transition-all",
                  wind === 'left' ? "bg-amber-500 text-white" : "text-gray-500"
                )}
                title="Draft Left"
              >
                <Wind className="w-3.5 h-3.5 rotate-180" />
              </button>
              <button 
                onClick={() => setWind(w => w === 'right' ? 'none' : 'right')}
                className={cn(
                  "p-1.5 rounded-lg text-xs transition-all",
                  wind === 'right' ? "bg-amber-500 text-white" : "text-gray-500"
                )}
                title="Draft Right"
              >
                <Wind className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Reset */}
            <button 
              onClick={handleResetDimensions}
              className="p-2 hover:bg-red-50 dark:hover:bg-red-950/30 text-red-500 rounded-xl transition-all border border-transparent hover:border-red-100 dark:hover:border-red-900/50"
              title="Reset Sandbox"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Physics Interactive Sandbox Viewport Container */}
      <div 
        ref={containerRef}
        onClick={handleContainerClick}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        className="flex-1 relative bg-gray-50/50 dark:bg-gray-950 overflow-hidden cursor-crosshair"
        style={{ touchAction: 'none' }}
      >
        {/* Background Instruction Note */}
        <div className="absolute inset-0 flex flex-col items-center justify-center opacity-10 dark:opacity-5 pointer-events-none select-none p-10 text-center">
          <Atom className="w-48 h-48 text-indigo-600 dark:text-white animate-spin-slow mb-6" />
          <h2 className="text-4xl font-black uppercase tracking-widest text-gray-900 dark:text-white">
            GRAVITATIONAL FIELD SIMULATOR
          </h2>
          <p className="max-w-md text-sm mt-3 leading-relaxed font-bold">
            Grab any module, slither with velocity, then release to toss. Click the open grid to emit sonic kinetic shockwaves.
          </p>
        </div>

        {/* Floating Phys-Objects */}
        {items.map((item) => {
          let content: React.ReactNode = null;

          // Render proper widget details for genuine engagement
          switch (item.type) {
            case 'instructions':
              content = (
                <div className="p-5 select-none h-full flex flex-col justify-between">
                  <div className="space-y-2">
                    <p className="text-[10px] font-black uppercase tracking-widest text-indigo-200">
                      AI Studio System Lab
                    </p>
                    <p className="text-xs leading-relaxed opacity-90">
                      Hover in a zero-gravity sphere of organization. Elements utilize coordinate drift:
                    </p>
                    <ul className="text-[10px] space-y-1 opacity-80 list-disc list-inside font-mono">
                      <li>Drag items with rapid cursor action.</li>
                      <li>Double-click/Tap back to stable.</li>
                      <li>Click blank workspace to blast grid files!</li>
                    </ul>
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px] border-t border-indigo-400/30 pt-3">
                    <Info className="w-3.5 h-3.5" />
                    <span>Dampener multiplier: {speedMultiplier}x</span>
                  </div>
                </div>
              );
              break;

            case 'tasks':
              content = (
                <div className="p-5 flex flex-col h-full overflow-hidden select-none">
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="text-xs font-black uppercase tracking-wider text-gray-400 dark:text-gray-500">
                      Active Tasks
                    </h3>
                    <span className="text-[10px] px-2 py-0.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-full font-bold">
                      {tasks.filter(t => t.status === 'Pending').length} Left
                    </span>
                  </div>

                  <form onSubmit={handleAddTask} className="flex gap-1.5 mb-3 select-text" onClick={e => e.stopPropagation()}>
                    <input 
                      type="text"
                      value={newTaskTitle}
                      onChange={e => setNewTaskTitle(e.target.value)}
                      placeholder="Add high-orbit task..."
                      className="flex-1 bg-gray-50 dark:bg-gray-800 text-[11px] px-2.5 py-1.5 rounded-lg border border-gray-100 dark:border-gray-750 focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:text-white"
                    />
                    <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 p-1.5 text-white rounded-lg">
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </form>

                  <div className="flex-1 overflow-y-auto space-y-1 pr-1" onClick={e => e.stopPropagation()}>
                    {tasks.slice(0, 4).map(task => (
                      <div 
                        key={task.id} 
                        className="flex items-center justify-between p-1.5 rounded-lg bg-gray-50/50 dark:bg-gray-800/40 border border-gray-100/30 dark:border-gray-800 text-[11px] group"
                      >
                        <button 
                          onClick={() => handleToggleTaskStatus(task.id)}
                          className={cn(
                            "w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors",
                            task.status === 'Done' ? "bg-emerald-500 border-emerald-500 text-white" : "border-gray-300 dark:border-gray-650"
                          )}
                        >
                          {task.status === 'Done' && <Check className="w-2.5 h-2.5" />}
                        </button>
                        <span className={cn(
                          "flex-1 text-left px-2 truncate leading-tight dark:text-gray-200",
                          task.status === 'Done' && "line-through text-gray-400 dark:text-gray-500"
                        )}>
                          {task.title}
                        </span>
                        <button 
                          onClick={() => handleDeleteTask(task.id)}
                          className="opacity-0 group-hover:opacity-100 p-1 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 rounded"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              );
              break;

            case 'pomodoro':
              content = (
                <div className="p-5 flex flex-col justify-between h-full select-none">
                  <div>
                    <h3 className="text-xs font-black uppercase tracking-wider text-gray-400 dark:text-gray-500">
                      Focus Session
                    </h3>
                    <div className="text-3xl font-black font-mono tracking-wider text-gray-900 dark:text-white mt-3 text-center">
                      {formatTime(timerSeconds)}
                    </div>
                  </div>

                  <div className="flex justify-center items-center gap-2 mt-4" onClick={e => e.stopPropagation()}>
                    {timerActive ? (
                      <button 
                        onClick={() => setTimerActive(false)}
                        className="px-3 py-1.5 bg-amber-500 text-white text-[10px] font-bold rounded-lg flex items-center gap-1 hover:bg-amber-600 transition-colors"
                      >
                        <Pause className="w-3 h-3" /> Pause
                      </button>
                    ) : (
                      <button 
                        onClick={() => setTimerActive(true)}
                        className="px-3 py-1.5 bg-emerald-500 text-white text-[10px] font-bold rounded-lg flex items-center gap-1 hover:bg-emerald-600 transition-colors"
                      >
                        <Play className="w-3 h-3" /> Focus
                      </button>
                    )}
                    <button 
                      onClick={() => { setTimerActive(false); setTimerSeconds(1500); }}
                      className="px-2 py-1.5 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 text-[10px] font-bold rounded-lg transition-colors"
                    >
                      Reset
                    </button>
                  </div>
                </div>
              );
              break;

            case 'attendance':
              const avg = Math.round(
                DUMMY_ATTENDANCE.reduce((acc, curr) => acc + (curr.attended / curr.total), 0) / DUMMY_ATTENDANCE.length * 100
              );
              content = (
                <div className="p-5 flex flex-col justify-between h-full select-none">
                  <h3 className="text-xs font-black uppercase tracking-wider text-gray-400 dark:text-gray-500">
                    Attendance Index
                  </h3>

                  <div className="flex items-center gap-3 my-2 bg-indigo-500/10 dark:bg-indigo-950/20 p-3 rounded-2xl">
                    <div className="relative w-12 h-12 rounded-full border-4 border-indigo-500/35 flex items-center justify-center">
                      <span className="text-xs font-black text-indigo-600 dark:text-indigo-400">{avg}%</span>
                    </div>
                    <div>
                      <p className="text-[11px] font-bold text-gray-700 dark:text-gray-300">Class Health standing</p>
                      <p className="text-[9px] text-gray-400 font-mono mt-0.5">Overall: Good standing</p>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    {DUMMY_ATTENDANCE.slice(0, 3).map(rec => (
                      <div key={rec.subject} className="flex justify-between items-center text-[10px]">
                        <span className="font-semibold text-gray-650 dark:text-gray-400">{rec.subject}</span>
                        <span className="font-mono text-gray-450 dark:text-gray-550">{rec.attended}/{rec.total} classes</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
              break;

            case 'scratchpad':
              content = (
                <div className="p-5 flex flex-col h-full overflow-hidden select-none">
                  <h3 className="text-xs font-black uppercase tracking-wider text-gray-400 dark:text-gray-500 mb-2">
                    G-Zero Thoughts
                  </h3>
                  <textarea 
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    onClick={e => e.stopPropagation()}
                    className="flex-1 w-full p-2 bg-gray-50 dark:bg-gray-850 border border-gray-100 dark:border-gray-800 rounded-xl text-[11px] font-mono leading-relaxed text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 select-text resize-none"
                  />
                </div>
              );
              break;

            case 'profile':
              content = (
                <div className="p-5 flex flex-col justify-between h-full select-none">
                  <div className="flex items-center gap-3">
                    <img 
                      src={user.profilePic || "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=200"} 
                      alt={user.name} 
                      className="w-12 h-12 rounded-full object-cover border-2 border-indigo-500/20"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <h4 className="font-black text-sm text-gray-900 dark:text-white truncate max-w-[150px]">{user.name}</h4>
                      <p className="text-[9px] text-indigo-500 uppercase tracking-widest font-black mt-0.5">Commander</p>
                    </div>
                  </div>

                  <div className="border-t border-gray-100 dark:border-gray-800 pt-3 flex items-center justify-between mt-2">
                    <div>
                      <span className="text-[9px] text-gray-400 block uppercase">CQ-Sector</span>
                      <span className="text-[10px] font-bold text-gray-700 dark:text-gray-200">{user.course}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-[9px] text-gray-400 block uppercase">GPA Rank</span>
                      <span className="text-[10px] font-black text-emerald-500">{user.cgpa} CGPA</span>
                    </div>
                  </div>
                </div>
              );
              break;

            default:
              content = <div className="p-5 font-bold text-center">System File Null</div>;
          }

          return (
            <div
              key={item.id}
              onPointerDown={(e) => handlePointerDown(item.id, e)}
              className={cn(
                "absolute rounded-[2rem] overflow-hidden select-none transition-shadow",
                item.colorClass,
                item.isDragging ? "shadow-2xl ring-2 ring-indigo-500/40 cursor-grabbing scale-[1.02] z-50" : "cursor-grab shadow-lg hover:shadow-2xl z-20"
              )}
              style={{
                width: `${item.width}px`,
                height: `${item.height}px`,
                left: 0,
                top: 0,
                transform: `translateX(${item.x}px) translateY(${item.y}px) rotate(${item.angle}rad)`,
                transformOrigin: 'center center',
                willChange: 'transform'
              }}
            >
              {/* Header handle element */}
              <div className="px-5 py-2.5 bg-gray-50/50 dark:bg-gray-800/50 border-b border-gray-100/30 dark:border-gray-855/35 flex items-center justify-between text-[10px] font-bold text-gray-400 tracking-wider uppercase select-none">
                <span className="truncate max-w-[80%]">{item.title}</span>
                <div className="flex gap-1 shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-gray-300 dark:bg-gray-600" />
                  <span className="w-1.5 h-1.5 rounded-full bg-gray-300 dark:bg-gray-600" />
                  <span className="w-1.5 h-1.5 rounded-full bg-gray-300 dark:bg-gray-600" />
                </div>
              </div>
              
              {/* Card Contents */}
              <div className="h-[calc(100%-27px)]">
                {content}
              </div>
            </div>
          );
        })}

        {/* Chaos Asteroids Canvas Spheres */}
        {asteroids.map((ast) => (
          <div
            key={ast.id}
            className="absolute rounded-full pointer-events-none transition-shadow duration-300 shadow-lg"
            style={{
              width: `${ast.radius * 2}px`,
              height: `${ast.radius * 2}px`,
              left: `${ast.x - ast.radius}px`,
              top: `${ast.y - ast.radius}px`,
              backgroundColor: ast.color,
              filter: 'brightness(1.1) drop-shadow(0 4px 6px rgba(0, 0, 0, 0.1))`',
              willChange: 'transform, left, top'
            }}
          />
        ))}
      </div>
    </div>
  );
}
