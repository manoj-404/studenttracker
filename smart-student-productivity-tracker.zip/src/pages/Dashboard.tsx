import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  Sparkles, 
  CheckCircle2, 
  Clock, 
  TrendingUp, 
  AlertCircle,
  GraduationCap,
  Atom
} from 'lucide-react';
import { DUMMY_TASKS, DUMMY_ATTENDANCE, AI_SUGGESTIONS } from '../constants';
import { useUser } from '../context/UserContext';
import { cn } from '../lib/utils';

export default function Dashboard() {
  const { user } = useUser();
  const attendanceAvg = Math.round(
    DUMMY_ATTENDANCE.reduce((acc, curr) => acc + (curr.attended / curr.total), 0) / DUMMY_ATTENDANCE.length * 100
  );

  return (
    <div className="space-y-8">
      <header className="mb-10">
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-black text-gray-900 dark:text-white tracking-tight"
        >
          Welcome back, {user.name} 👋
        </motion.h1>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-3">
          <p className="text-gray-500 dark:text-gray-400 font-bold uppercase tracking-[0.2em] text-xs leading-none">{user.course} • {user.year}</p>
          <Link 
            to="/antigravity" 
            className="flex items-center gap-1.5 text-xs text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 font-bold hover:underline transition-all w-fit"
          >
            <Atom className="w-3.5 h-3.5 animate-spin-slow text-indigo-500" />
            Launch Google Antigravity Lab →
          </Link>
        </div>
      </header>

      {/* Quick Stats - Premium Enlarged Design */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-gray-900 p-10 rounded-[3rem] shadow-xl border border-gray-100 dark:border-gray-800 flex items-center justify-between transition-all duration-300 group hover:border-indigo-200 dark:hover:border-indigo-800"
        >
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 mb-2">Academic Standing</p>
            <div className="flex items-baseline gap-2">
              <h3 className="text-6xl font-black text-gray-900 dark:text-white leading-none">{user.cgpa}</h3>
              <span className="text-gray-400 font-bold text-xl uppercase tracking-tighter">CGPA</span>
            </div>
            <div className="flex items-center gap-2 mt-4 text-emerald-500 font-black text-[10px] uppercase tracking-widest bg-emerald-50 dark:bg-emerald-900/20 px-3 py-1 rounded-full w-fit">
              <TrendingUp className="w-3 h-3" />
              Top 5% of Class
            </div>
          </div>
          <div className="p-6 bg-indigo-600 rounded-[2.5rem] text-white shadow-2xl shadow-indigo-200 dark:shadow-none transition-transform duration-500 group-hover:rotate-12">
            <GraduationCap className="w-10 h-10" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white dark:bg-gray-900 p-10 rounded-[3rem] shadow-xl border border-gray-100 dark:border-gray-800 flex items-center justify-between transition-all duration-300 group hover:border-amber-200 dark:hover:border-amber-800"
        >
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 mb-2">Priority Missions</p>
            <div className="flex items-baseline gap-2">
              <h3 className="text-6xl font-black text-gray-900 dark:text-white leading-none">{DUMMY_TASKS.filter(t => t.status === 'Pending').length}</h3>
              <span className="text-gray-400 font-bold text-xl uppercase tracking-tighter">Tasks</span>
            </div>
            <div className="flex items-center gap-2 mt-4 text-amber-500 font-black text-[10px] uppercase tracking-widest bg-amber-50 dark:bg-amber-900/20 px-3 py-1 rounded-full w-fit">
              <Clock className="w-3 h-3" />
              Due Soon
            </div>
          </div>
          <div className="p-6 bg-amber-500 rounded-[2.5rem] text-white shadow-2xl shadow-amber-100 dark:shadow-none transition-transform duration-500 group-hover:-rotate-12">
            <CheckCircle2 className="w-10 h-10" />
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Upcoming Tasks */}
        <motion.section
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white dark:bg-gray-900 p-8 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 space-y-6 transition-colors duration-300"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">Upcoming Tasks</h2>
            <button className="text-sm font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 transition-colors">View All</button>
          </div>
          <div className="space-y-4">
            {DUMMY_TASKS.filter(t => t.status === 'Pending').slice(0, 3).map((task) => (
              <div key={task.id} className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50 border border-gray-100 dark:border-gray-800 transition-colors">
                <div className="w-2 h-10 bg-amber-400 rounded-full" />
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">{task.title}</h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center gap-1.5 mt-0.5">
                    <Clock className="w-3.5 h-3.5" />
                    Due {task.dueDate}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </motion.section>

        {/* AI Suggestions Box */}
        <motion.section
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="relative overflow-hidden group bg-indigo-600 p-8 rounded-3xl shadow-lg shadow-indigo-200 text-white"
        >
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
          <div className="relative space-y-6">
            <div className="flex items-center gap-2 px-3 py-1 bg-white/20 w-fit rounded-full">
              <Sparkles className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-widest">AI Insights</span>
            </div>
            <div className="space-y-4">
              {AI_SUGGESTIONS.map((suggestion, i) => (
                <div key={i} className="flex items-start gap-4">
                  <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-indigo-200 shrink-0" />
                  <p className="text-lg font-medium leading-relaxed italic opacity-95">
                    "{suggestion}"
                  </p>
                </div>
              ))}
            </div>
          </div>
        </motion.section>
      </div>
    </div>
  );
}
