import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, RotateCcw, Coffee, BookOpen, Bell, Zap, Trophy } from 'lucide-react';
import { cn } from '../lib/utils';

type TimerMode = 'study' | 'break';

interface SessionStats {
  completedStudy: number;
  completedBreak: number;
  focusSeconds: number;
  breakSeconds: number;
}

export default function FocusTimer() {
  const [mode, setMode] = useState<TimerMode>('study');
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [sessions, setSessions] = useState<SessionStats>({
    completedStudy: 0,
    completedBreak: 0,
    focusSeconds: 0,
    breakSeconds: 0
  });
  const [sessionStartedAt, setSessionStartedAt] = useState<number | null>(null);
  const [customTimes, setCustomTimes] = useState({
    study: 25,
    break: 5
  });

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Helper to accumulate time spent
  const accumulateTime = (currentMode: TimerMode, currentTimeLeft: number) => {
    if (sessionStartedAt !== null) {
      const elapsed = sessionStartedAt - currentTimeLeft;
      if (elapsed > 0) {
        setSessions(prev => ({
          ...prev,
          focusSeconds: currentMode === 'study' ? prev.focusSeconds + elapsed : prev.focusSeconds,
          breakSeconds: currentMode === 'break' ? prev.breakSeconds + elapsed : prev.breakSeconds
        }));
      }
      setSessionStartedAt(null);
    }
  };

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      // If we just started, record the start time
      if (sessionStartedAt === null) {
        setSessionStartedAt(timeLeft);
      }
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      handleTimerComplete();
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, timeLeft]);

  const handleTimerComplete = () => {
    setIsActive(false);
    accumulateTime(mode, 0); // Accumulate all remaining time

    if (mode === 'study') {
       setSessions(prev => ({
         ...prev,
         completedStudy: prev.completedStudy + 1
       }));
       setMode('break');
       setTimeLeft(customTimes.break * 60);
    } else {
      setSessions(prev => ({
        ...prev,
        completedBreak: prev.completedBreak + 1
      }));
      setMode('study');
      setTimeLeft(customTimes.study * 60);
    }
  };

  const toggleTimer = () => {
    if (isActive) {
      // Pausing: Accumulate time
      accumulateTime(mode, timeLeft);
    }
    setIsActive(!isActive);
  };

  const resetTimer = () => {
    accumulateTime(mode, timeLeft);
    setIsActive(false);
    setTimeLeft(mode === 'study' ? customTimes.study * 60 : customTimes.break * 60);
  };

  const switchMode = (newMode: TimerMode) => {
    if (mode !== newMode) {
      accumulateTime(mode, timeLeft);
      setMode(newMode);
      setIsActive(false);
      setTimeLeft(newMode === 'study' ? customTimes.study * 60 : customTimes.break * 60);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = mode === 'study' 
    ? (timeLeft / (customTimes.study * 60)) * 100 
    : (timeLeft / (customTimes.break * 60)) * 100;

  return (
    <div className="space-y-8 max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight">Focus & Break</h1>
          <p className="text-gray-500 dark:text-gray-400 font-medium tracking-tight">
            Master your attention with structured focus sessions.
          </p>
        </div>
      </header>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main Timer Section */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-gray-900 rounded-[2.5rem] p-12 border border-gray-100 dark:border-gray-800 shadow-2xl flex flex-col items-center transition-colors">
            {/* Mode Switcher */}
            <div className="flex p-1 bg-gray-100 dark:bg-gray-800 rounded-2xl mb-12">
              <button
                onClick={() => switchMode('study')}
                className={cn(
                  "flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                  mode === 'study' 
                    ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200 dark:shadow-none" 
                    : "text-gray-500 hover:text-gray-900 dark:hover:text-white"
                )}
              >
                <BookOpen className="w-4 h-4" />
                Focus Mode
              </button>
              <button
                onClick={() => switchMode('break')}
                className={cn(
                  "flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                  mode === 'break' 
                    ? "bg-rose-500 text-white shadow-lg shadow-rose-200 dark:shadow-none" 
                    : "text-gray-500 hover:text-gray-900 dark:hover:text-white"
                )}
              >
                <Coffee className="w-4 h-4" />
                Short Break
              </button>
            </div>

            {/* Timer Display */}
            <div className="relative w-72 h-72 flex items-center justify-center mb-12">
              <svg className="w-full h-full -rotate-90">
                <circle
                  cx="144"
                  cy="144"
                  r="135"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="transparent"
                  className="text-gray-100 dark:text-gray-800"
                />
                <motion.circle
                  cx="144"
                  cy="144"
                  r="135"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="transparent"
                  strokeDasharray="848.23"
                  animate={{ strokeDashoffset: 848.23 * (1 - progress / 100) }}
                  transition={{ duration: 1, ease: 'linear' }}
                  className={cn(
                    "transition-colors duration-500",
                    mode === 'study' ? "text-indigo-600" : "text-rose-500"
                  )}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-7xl font-black text-gray-900 dark:text-white tabular-nums tracking-tighter">
                  {formatTime(timeLeft)}
                </span>
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-400 mt-2">
                  {isActive ? (mode === 'study' ? 'Burning Focus' : 'Cooling Down') : 'PAUSED'}
                </span>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-6">
              <button
                onClick={resetTimer}
                className="p-4 rounded-2xl bg-gray-100 dark:bg-gray-800 text-gray-500 hover:text-gray-900 dark:hover:text-white transition-all hover:scale-105 active:scale-95"
              >
                <RotateCcw className="w-6 h-6" />
              </button>
              <button
                onClick={toggleTimer}
                className={cn(
                  "w-20 h-20 rounded-[2rem] flex items-center justify-center text-white transition-all hover:scale-105 active:scale-95 shadow-xl",
                  mode === 'study' 
                    ? "bg-indigo-600 shadow-indigo-200 dark:shadow-none" 
                    : "bg-rose-500 shadow-rose-200 dark:shadow-none"
                )}
              >
                {isActive ? (
                  <Pause className="w-8 h-8 fill-white" />
                ) : (
                  <Play className="w-8 h-8 fill-white ml-1" />
                )}
              </button>
              <div className="w-14 h-14" /> {/* Spacer for balance */}
            </div>
          </div>

          {/* Quick Settings */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white dark:bg-gray-900 p-6 rounded-3xl border border-gray-100 dark:border-gray-800 transition-colors">
              <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-4 block">Study Duration</label>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-black text-gray-900 dark:text-white">{customTimes.study}m</span>
                <div className="flex gap-1">
                  <button onClick={() => setCustomTimes(p => ({...p, study: Math.max(1, p.study - 5)}))} className="p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg text-gray-400">-</button>
                  <button onClick={() => setCustomTimes(p => ({...p, study: p.study + 5}))} className="p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg text-gray-400">+</button>
                </div>
              </div>
            </div>
            <div className="bg-white dark:bg-gray-900 p-6 rounded-3xl border border-gray-100 dark:border-gray-800 transition-colors">
              <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-4 block">Break Duration</label>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-black text-gray-900 dark:text-white">{customTimes.break}m</span>
                <div className="flex gap-1">
                  <button onClick={() => setCustomTimes(p => ({...p, break: Math.max(1, p.break - 1)}))} className="p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg text-gray-400">-</button>
                  <button onClick={() => setCustomTimes(p => ({...p, break: p.break + 1}))} className="p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg text-gray-400">+</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Column */}
        <div className="space-y-6">
          <div className="bg-gradient-to-br from-indigo-600 to-indigo-700 p-8 rounded-[2.5rem] text-white shadow-xl">
            <h3 className="text-sm font-black uppercase tracking-widest opacity-80 mb-6">Today's Focus</h3>
            <div className="space-y-6">
              <div>
                <span className="text-4xl font-black">{Math.floor(sessions.focusSeconds / 60)}</span>
                <span className="text-sm font-bold opacity-80 ml-2 uppercase tracking-widest">Study Session (Mins)</span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/10 p-4 rounded-2xl backdrop-blur-md">
                  <div className="text-[10px] font-black uppercase tracking-widest opacity-60 mb-1">Total Sessions</div>
                  <div className="text-xl font-black">{sessions.completedStudy}</div>
                </div>
                <div className="bg-white/10 p-4 rounded-2xl backdrop-blur-md">
                  <div className="text-[10px] font-black uppercase tracking-widest opacity-60 mb-1">Break Time</div>
                  <div className="text-xl font-black">{Math.floor(sessions.breakSeconds / 60)}m</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
