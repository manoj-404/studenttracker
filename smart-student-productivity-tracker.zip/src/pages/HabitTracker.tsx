import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, Plus, ChevronRight, Flame, Heart, BookOpen, Droplets, MessageSquare, Zap, Monitor, Code, Layout, GraduationCap, X, Bell } from 'lucide-react';
import { cn } from '../lib/utils';

interface Habit {
  id: string;
  name: string;
  category: string;
  detail: string;
  completed: boolean;
  icon?: React.ReactNode;
}

const INITIAL_HABITS: Habit[] = [
  { id: '1', name: 'Sleep 8 Hours', category: 'Wellness', detail: '07:00 AM', completed: false, icon: <Zap className="w-4 h-4" /> },
  { id: '2', name: 'Exercise (30 min)', category: 'Wellness', detail: 'Morning Session', completed: false, icon: <Heart className="w-4 h-4" /> },
  { id: '3', name: 'Study (1 hour)', category: 'Academic', detail: 'Core Focus', completed: false, icon: <BookOpen className="w-4 h-4" /> },
  { id: '4', name: 'Drink Water (>2 Ltr)', category: 'Wellness', detail: 'Hydration Goal', completed: false, icon: <Droplets className="w-4 h-4" /> },
  { id: '5', name: 'Speaking Practice', category: 'Skills', detail: 'Communication', completed: false, icon: <MessageSquare className="w-4 h-4" /> },
  { id: '6', name: 'Clear Doubts', category: 'Academic', detail: 'Q&A Session', completed: false, icon: <GraduationCap className="w-4 h-4" /> },
  { id: '7', name: 'Project Process', category: 'Engineering', detail: 'Documentation', completed: false, icon: <Monitor className="w-4 h-4" /> },
  { id: '8', name: 'Code Practice', category: 'Skills', detail: 'LeetCode/GitHub', completed: false, icon: <Code className="w-4 h-4" /> },
  { id: '9', name: 'Read News', category: 'Growth', detail: 'Tech & Global', completed: false, icon: <Layout className="w-4 h-4" /> },
  { id: '10', name: 'Assignment Works', category: 'Academic', detail: 'Submissions', completed: false, icon: <GraduationCap className="w-4 h-4" /> },
];

export default function HabitTracker() {
  const [habits, setHabits] = useState(INITIAL_HABITS);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newHabit, setNewHabit] = useState({ name: '', category: '', detail: '' });
  const [lastCompletedId, setLastCompletedId] = useState<string | null>(null);
  
  // Consistency state
  const [isConsistent, setIsConsistent] = useState(false);
  const [showNotification, setShowNotification] = useState(false);

  // Persistence and daily logic
  useEffect(() => {
    const checkConsistency = () => {
      const now = new Date();
      const hours = now.getHours();

      // Check for daily reset
      const lastResetDate = localStorage.getItem('habit_last_reset_date');
      const todayDate = now.toDateString();

      const atLeastOneDone = habits.some(h => h.completed);

      if (lastResetDate && lastResetDate !== todayDate) {
        // New Day: Start fresh
        setHabits(prev => prev.map(h => ({ ...h, completed: false })));
        localStorage.setItem('habit_at_least_one_done', 'false');
        localStorage.setItem('habit_last_reset_date', todayDate);
        localStorage.setItem('habit_notification_sent', 'false');
        setIsConsistent(false); // Reset to "disappeared" state for new day
      } else if (!lastResetDate) {
        localStorage.setItem('habit_last_reset_date', todayDate);
      }

      // If at least one done today, it glows!
      if (atLeastOneDone) {
        localStorage.setItem('habit_at_least_one_done', 'true');
        setIsConsistent(true);
      } else {
        setIsConsistent(false);
      }

      // 20-hour notification logic (if no habit completed by 8 PM)
      const notificationSentToday = localStorage.getItem('habit_notification_sent') === 'true';

      if (hours >= 20 && !atLeastOneDone && !notificationSentToday) {
        setShowNotification(true);
        localStorage.setItem('habit_notification_sent', 'true');
        setTimeout(() => setShowNotification(false), 10000); // Hide after 10s
      }
    };

    checkConsistency();
    const interval = setInterval(checkConsistency, 10000); // Check more frequently for responsiveness
    return () => clearInterval(interval);
  }, [habits]);

  const toggleHabit = (id: string) => {
    setHabits(prev => {
      const newHabits = prev.map(h => {
        if (h.id === id) {
          const newCompleted = !h.completed;
          if (newCompleted) {
            setLastCompletedId(id);
            setTimeout(() => setLastCompletedId(null), 1000);
          }
          return { ...h, completed: newCompleted };
        }
        return h;
      });
      return newHabits;
    });
  };

  const completedCount = habits.filter(h => h.completed).length;

  const handleAddHabit = () => {
    if (!newHabit.name || !newHabit.category) return;
    const habit: Habit = {
      id: Math.random().toString(36).substr(2, 9),
      ...newHabit,
      completed: false,
      icon: <Check className="w-4 h-4" />
    };
    setHabits(prev => [...prev, habit]);
    setNewHabit({ name: '', category: '', detail: '' });
    setShowAddModal(false);
  };

  return (
    <div className="relative space-y-6 max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700">
      
      {/* Consistency Fire Burst Corner Emoji */}
      <div className="fixed top-8 right-8 z-[60] group cursor-help">
        <motion.div
          animate={{ scale: isConsistent ? [1, 1.1, 1] : 1 }}
          transition={{ duration: 2, repeat: Infinity }}
          className={cn(
            "p-4 rounded-full bg-white dark:bg-gray-900 shadow-2xl border flex items-center justify-center transition-all duration-700",
            isConsistent ? "border-orange-200 dark:border-orange-900/50" : "border-gray-200 dark:border-gray-800 grayscale opacity-40 bg-gray-50"
          )}
        >
          <span className={cn("text-4xl", !isConsistent && "filter drop-shadow-sm font-bold")}>
            {isConsistent ? "🔥" : "🌑"}
          </span>
          
          {/* Tooltip */}
          <div className="absolute right-full mr-4 top-1/2 -translate-y-1/2 bg-gray-900 text-white px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none shadow-xl">
            {isConsistent ? "Consistent • Fire Burst Active!" : "Consistency Disappeared • Recover Now!"}
          </div>
        </motion.div>
      </div>

      {/* Daily Notification Toast */}
      <AnimatePresence>
        {showNotification && (
          <motion.div 
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 100 }}
            className="fixed bottom-8 right-8 z-[200] w-80 bg-rose-600 text-white p-6 rounded-[2rem] shadow-2xl shadow-rose-200 dark:shadow-none flex items-center gap-4"
          >
            <div className="p-3 bg-white/20 rounded-2xl">
              <Bell className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <h4 className="font-black text-xs uppercase tracking-widest">Inconsistency Alert!</h4>
              <p className="text-[10px] font-bold text-rose-100 leading-tight">20 hours passed and no habits completed. Don't lose your streak!</p>
            </div>
            <button onClick={() => setShowNotification(false)} className="ml-auto p-1.5 hover:bg-white/10 rounded-full">
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <header className="space-y-1">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white tracking-tight">Habit Tracker</h1>
        <p className="text-gray-400 dark:text-gray-500 font-medium text-xs">Building consistency, one day at a time.</p>
      </header>

      <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-2xl overflow-hidden p-6 md:p-8 transition-colors">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Daily Habits</h2>
          <div className="flex items-center gap-2 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-100 dark:border-emerald-800">
            {completedCount}/{habits.length} Complete • Keep Going!
          </div>
        </div>

        <div className="space-y-3">
          {habits.map((habit) => (
            <motion.div
              key={habit.id}
              layout
              className={cn(
                "group relative flex items-center gap-4 p-4 rounded-2xl border transition-all cursor-pointer",
                habit.completed 
                  ? "bg-indigo-50/50 dark:bg-indigo-900/10 border-indigo-100/50 dark:border-indigo-800/50 text-indigo-900 dark:text-indigo-100" 
                  : "bg-white dark:bg-gray-900 border-gray-100 dark:border-gray-800 hover:border-indigo-200 dark:hover:border-indigo-700 font-bold"
              )}
              onClick={() => toggleHabit(habit.id)}
            >
              {/* Fire Animation */}
              <AnimatePresence>
                {lastCompletedId === habit.id && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.5, y: 0 }}
                    animate={{ 
                      opacity: [0, 1, 1, 0], 
                      scale: [1, 2.5, 3, 2],
                      y: -50,
                      x: [0, 15, -15, 0]
                    }}
                    exit={{ opacity: 0 }}
                    className="absolute left-4 top-4 text-3xl pointer-events-none z-10"
                  >
                    🔥
                  </motion.div>
                )}
              </AnimatePresence>
              <div className={cn(
                "w-7 h-7 rounded-lg flex items-center justify-center transition-all",
                habit.completed ? "bg-orange-500 text-white shadow-lg shadow-orange-100 dark:shadow-none" : "bg-gray-100 dark:bg-gray-800 text-gray-400 group-hover:bg-orange-50 dark:group-hover:bg-orange-900/30 group-hover:text-orange-400"
              )}>
                {habit.completed ? <span className="text-xs">🔥</span> : habit.icon}
              </div>
              
              <div className="flex-1">
                <h3 className={cn("text-sm font-bold", habit.completed ? "text-indigo-900 dark:text-indigo-100" : "text-gray-700 dark:text-gray-300")}>
                  {habit.name}
                </h3>
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">
                  {habit.category} • {habit.detail}
                </p>
              </div>

              <ChevronRight className={cn("w-4 h-4 transition-all opacity-0 group-hover:opacity-100", habit.completed ? "text-indigo-300 dark:text-indigo-500" : "text-gray-300 dark:text-gray-600")} />
            </motion.div>
          ))}
        </div>

        <button 
          onClick={() => setShowAddModal(true)}
          className="w-full mt-6 flex items-center justify-center gap-2 p-4 border-2 border-dashed border-gray-100 rounded-2xl text-gray-400 font-bold text-xs uppercase tracking-widest hover:border-indigo-200 hover:text-indigo-400 hover:bg-indigo-50/20 transition-all active:scale-[0.99]"
        >
          <Plus className="w-4 h-4" />
          Add New Daily Habit
        </button>
      </div>

      {/* Add Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white dark:bg-gray-900 w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden border border-gray-100 dark:border-gray-800"
            >
              <div className="p-8 space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-black text-gray-900 dark:text-white italic tracking-tight">New Habit</h3>
                  <button onClick={() => setShowAddModal(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors">
                    <X className="w-5 h-5 text-gray-400" />
                  </button>
                </div>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 dark:text-gray-500">Habit Name</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Meditate"
                      className="w-full p-4 bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600 transition-all font-bold dark:text-white"
                      value={newHabit.name}
                      onChange={e => setNewHabit({...newHabit, name: e.target.value})}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 dark:text-gray-500">Category</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Wellness"
                        className="w-full p-4 bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600 transition-all font-bold dark:text-white"
                        value={newHabit.category}
                        onChange={e => setNewHabit({...newHabit, category: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 dark:text-gray-500">Time/Detail</label>
                      <input 
                        type="text" 
                        placeholder="e.g. 5 Mins"
                        className="w-full p-4 bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600 transition-all font-bold dark:text-white"
                        value={newHabit.detail}
                        onChange={e => setNewHabit({...newHabit, detail: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <button 
                  onClick={handleAddHabit}
                  className="w-full bg-indigo-600 text-white py-5 rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-[0.98]"
                >
                  Create Habit
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
