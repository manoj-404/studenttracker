import React from 'react';
import { Bell, Info, AlertTriangle, XCircle, CheckCircle2, ChevronRight } from 'lucide-react';
import { DUMMY_NOTIFICATIONS } from '../constants';
import { cn } from '../lib/utils';

export default function Notifications() {
  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight">Notifications</h1>
          <p className="text-gray-500 dark:text-gray-400 font-medium tracking-tight">Stay updated with your academic alerts and reminders.</p>
        </div>
        <div />
      </header>

      <div className="space-y-4">
        {DUMMY_NOTIFICATIONS.map((notif) => (
          <div 
            key={notif.id}
            className="group bg-white dark:bg-gray-900 p-6 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-sm hover:shadow-md transition-all flex items-start gap-4"
          >
            <div className={cn(
              "p-3 rounded-2xl shrink-0",
              notif.type === 'warning' && "bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400",
              notif.type === 'error' && "bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400",
              notif.type === 'info' && "bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400",
              notif.type === 'success' && "bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400",
            )}>
              {notif.type === 'warning' && <AlertTriangle className="w-5 h-5" />}
              {notif.type === 'error' && <XCircle className="w-5 h-5" />}
              {notif.type === 'info' && <Info className="w-5 h-5" />}
              {notif.type === 'success' && <CheckCircle2 className="w-5 h-5" />}
            </div>
            
            <div className="flex-1 space-y-1">
              <div className="flex justify-between items-start">
                <h3 className="font-bold text-gray-900 dark:text-white">{notif.title}</h3>
                <span className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest">{notif.time}</span>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400 font-medium leading-relaxed">
                {notif.description}
              </p>
            </div>

            <button className="p-2 text-gray-300 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all opacity-0 group-hover:opacity-100">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      <div className="bg-gray-50 p-6 rounded-3xl border-2 border-dashed border-gray-200 text-center">
        <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">No more notifications</p>
      </div>
    </div>
  );
}
