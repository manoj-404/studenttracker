import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TrendingUp, TrendingDown, Target, Award, Edit2, Save, X, Plus, Trash2, Calendar, ChevronRight, Calculator, Check, Sparkles, Loader2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { DUMMY_PERFORMANCE } from '../constants';
import { useUser } from '../context/UserContext';
import { cn } from '../lib/utils';

import { analyzePerformance } from '../services/geminiService';

const GRADE_POINTS: Record<string, number> = {
  'S': 10,
  'A+': 9,
  'A': 8,
  'B+': 7,
  'B': 6.5,
  'C+': 6,
  'C': 5,
  'U': 0
};

interface GradeCalculatorProps {
  onSave: (gpa: number, subjects: number, arrears: number) => void;
}

function GradeCalculator({ onSave }: GradeCalculatorProps) {
  const [selectedGrades, setSelectedGrades] = useState<string[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  
  const totalPoints = selectedGrades.reduce((sum, g) => sum + (GRADE_POINTS[g] || 0), 0);
  const average = selectedGrades.length > 0 ? totalPoints / selectedGrades.length : 0;
  const currentArrears = selectedGrades.filter(g => g === 'U').length;
  
  const addGrade = (grade: string) => {
    setSelectedGrades(prev => [...prev, grade]);
  };
  
  const clear = () => setSelectedGrades([]);
  
  const removeGrade = (index: number) => {
    setSelectedGrades(prev => prev.filter((_, i) => i !== index));
  };

  const handleSave = () => {
    if (selectedGrades.length === 0) return;
    setIsSaving(true);
    onSave(average, selectedGrades.length, currentArrears);
    setTimeout(() => {
      setIsSaving(false);
      clear();
    }, 600);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-4 md:grid-cols-8 gap-3">
        {Object.keys(GRADE_POINTS).map((grade) => (
          <button
            key={grade}
            onClick={() => addGrade(grade)}
            className="flex flex-col items-center justify-center p-4 rounded-2xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 hover:border-indigo-500 dark:hover:border-indigo-400 hover:shadow-lg transition-all group active:scale-95"
          >
            <span className="text-xl font-black text-gray-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400">{grade}</span>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{GRADE_POINTS[grade]} pts</span>
          </button>
        ))}
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex-1 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-gray-400">Selected Grades</h4>
            <button 
              onClick={clear}
              className="text-[10px] font-black uppercase tracking-widest text-rose-500 hover:text-rose-600 transition-colors"
            >
              Clear All
            </button>
          </div>
          <div className="flex flex-wrap gap-2 min-h-[60px] p-4 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-dashed border-gray-200 dark:border-gray-700">
            {selectedGrades.length === 0 ? (
              <p className="text-xs text-gray-400 font-medium italic">No grades selected yet...</p>
            ) : (
              selectedGrades.map((grade, idx) => (
                <motion.button
                  key={`${grade}-${idx}`}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  onClick={() => removeGrade(idx)}
                  className="px-3 py-1.5 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 rounded-lg text-sm font-bold flex items-center gap-2 hover:bg-rose-100 hover:text-rose-700 dark:hover:bg-rose-900/30 dark:hover:text-rose-300 transition-all group"
                  title="Remove grade"
                >
                  {grade}
                  <X className="w-3 h-3 opacity-50 group-hover:opacity-100" />
                </motion.button>
              ))
            )}
          </div>
        </div>

        <div className="w-full md:w-80 flex flex-col gap-4">
          <div className="bg-emerald-600 p-6 rounded-[2rem] text-white flex flex-col items-center justify-center shadow-xl shadow-emerald-200 dark:shadow-none">
            <span className="text-[10px] font-black uppercase tracking-widest text-emerald-100 mb-1">Total Points Sum</span>
            <span className="text-4xl font-black tracking-tighter">{totalPoints.toFixed(1)}</span>
          </div>
          
          <div className="bg-indigo-600 p-6 rounded-[2rem] text-white flex flex-col items-center justify-center shadow-xl shadow-indigo-200 dark:shadow-none relative group">
            <span className="text-[10px] font-black uppercase tracking-widest text-indigo-200 mb-1">Calculated Average</span>
            <span className="text-4xl font-black tracking-tighter">{average.toFixed(2)}</span>
            <p className="mt-2 text-[10px] font-bold text-indigo-100/60 leading-relaxed uppercase">
              {selectedGrades.length} Subjects
            </p>
            
            {selectedGrades.length > 0 && (
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="mt-4 w-full bg-white text-indigo-600 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-50 transition-all flex items-center justify-center gap-2 shadow-lg active:scale-95 disabled:opacity-50"
              >
                {isSaving ? (
                  <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}>
                    <Save className="w-3 h-3" />
                  </motion.div>
                ) : (
                  <Save className="w-3 h-3" />
                )}
                Save to History
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Performance() {
  const { user, updateUser } = useUser();
  const [performance, setPerformance] = useState(DUMMY_PERFORMANCE);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newSubjectName, setNewSubjectName] = useState('');

  const handleUpdateMark = (subject: string, field: 'test1' | 'test2' | 'semResult' | 'subject', value: string) => {
    setPerformance(prev => prev.map(p => {
      if (p.subject === subject || (field === 'subject' && p.subject === editingId)) {
        let updated = { ...p };
        if (field === 'test1' || field === 'test2' || field === 'semResult') {
          updated[field] = parseInt(value) || 0;
          // Calculate final as average of (Tests Average) and (Sem Result)
          updated.final = Math.round(((updated.test1 + updated.test2) / 2 * 0.4) + (updated.semResult * 0.6));
        } else {
          updated.subject = value;
        }
        return updated;
      }
      return p;
    }));
    if (field === 'subject') setEditingId(value);
  };

  const handleAddSubject = () => {
    if (!newSubjectName.trim()) return;
    // Check if subject already exists to avoid duplicates
    if (performance.find(p => p.subject.toLowerCase() === newSubjectName.toLowerCase())) {
      alert("Subject already exists!");
      return;
    }
    const newRecord = {
      subject: newSubjectName,
      test1: 0,
      test2: 0,
      semResult: 0,
      final: 0
    };
    setPerformance(prev => [...prev, newRecord]);
    setNewSubjectName('');
    setShowAddModal(false);
  };

  const handleDeleteSubject = (subject: string) => {
    setPerformance(prev => prev.filter(p => p.subject !== subject));
  };

  // Editable semesters data state
  const [semesters, setSemesters] = useState([
    { id: 1, name: 'Semester 1', date: 'Jan 2025 - May 2025', gpa: 8.52, subjects: 6, arrears: 0 },
    { id: 2, name: 'Semester 2', date: 'Jul 2025 - Nov 2025', gpa: 8.85, subjects: 7, arrears: 1 },
    { id: 3, name: 'Semester 3', date: 'Jan 2026 - May 2026', gpa: 9.12, subjects: 6, arrears: 0 },
  ]);

  const calculateGPAPoint = (final: number) => {
    if (final >= 90) return 10;
    if (final >= 80) return 9;
    if (final >= 70) return 8;
    if (final >= 60) return 7;
    if (final >= 50) return 6;
    if (final >= 40) return 5;
    return 0;
  };

  const currentGPA = useMemo(() => {
    return performance.length > 0
      ? (performance.reduce((acc, curr) => acc + calculateGPAPoint(curr.final), 0) / performance.length).toFixed(2)
      : '0.00';
  }, [performance]);

  const cgpa = useMemo(() => {
    return semesters.length > 0
      ? (performance.length > 0 
          ? ((semesters.reduce((acc, curr) => acc + curr.gpa, 0) + parseFloat(currentGPA)) / (semesters.length + 1)).toFixed(2)
          : (semesters.reduce((acc, curr) => acc + curr.gpa, 0) / semesters.length).toFixed(2))
      : (performance.length > 0 ? currentGPA : '0.00');
  }, [semesters, performance, currentGPA]);

  useEffect(() => {
    const calculatedCgpaValue = parseFloat(cgpa);
    const totalArrears = semesters.reduce((acc, curr) => acc + (curr.arrears || 0), 0);
    
    // Check if the user in context actually needs an update to avoid loops
    if (!isNaN(calculatedCgpaValue)) {
      const needsUpdate = Math.abs(user.cgpa - calculatedCgpaValue) > 0.001 || user.arrears !== totalArrears;
      if (needsUpdate) {
        updateUser({ cgpa: calculatedCgpaValue, arrears: totalArrears });
      }
    }
  }, [cgpa, updateUser, user.cgpa, user.arrears, semesters]);

  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSaveAll = () => {
    setIsSaving(true);
    // Simulate a save operation
    setTimeout(() => {
      setIsSaving(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }, 800);
  };

  const handleUpdateSemester = (id: number, field: string, value: string) => {
    setSemesters(prev => prev.map(sem => 
      sem.id === id ? { ...sem, [field]: field === 'name' || field === 'date' ? value : parseFloat(value) || 0 } : sem
    ));
  };

  const handleAddSemester = () => {
    const newId = semesters.length > 0 ? Math.max(...semesters.map(s => s.id)) + 1 : 1;
    setSemesters([...semesters, {
      id: newId,
      name: `Semester ${newId}`,
      date: 'Jan-Jun 2027',
      gpa: 0,
      subjects: 0,
      arrears: 0
    }]);
  };

  const handleSaveCalculatedGpa = (gpa: number, subjects: number, arrears: number) => {
    const newId = semesters.length > 0 ? Math.max(...semesters.map(s => s.id)) + 1 : 1;
    setSemesters(prev => [...prev, {
      id: newId,
      name: `Semester ${newId}`,
      date: new Date().getFullYear().toString(),
      gpa: parseFloat(gpa.toFixed(2)),
      subjects: subjects,
      arrears: arrears
    }]);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);

  const handleAiAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      const resp = await analyzePerformance(performance);
      setAnalysis(resp || 'No analysis available.');
    } catch (err) {
      console.error(err);
      setAnalysis('Failed to generate AI analysis.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight">Academic Performance</h1>
          <p className="text-gray-500 dark:text-gray-400 font-medium tracking-tight">Detailed analysis of your subject-wise marks</p>
        </div>
        <button
          onClick={handleAiAnalysis}
          disabled={isAnalyzing || performance.length === 0}
          className="flex items-center gap-2 px-6 py-4 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-3xl text-sm font-black uppercase tracking-widest text-indigo-600 dark:text-indigo-400 hover:shadow-xl transition-all shadow-lg active:scale-95 disabled:opacity-50"
        >
          {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4 text-indigo-500" />}
          AI Insights
        </button>
      </header>

      <AnimatePresence>
        {analysis && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="bg-indigo-600 p-8 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden group mb-8">
              <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
              <div className="relative space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Sparkles className="w-5 h-5 text-indigo-200" />
                    <h3 className="font-bold uppercase tracking-widest text-xs">AI Performance Insights</h3>
                  </div>
                  <button onClick={() => setAnalysis(null)} className="p-2 hover:bg-white/10 rounded-full transition-all">
                    <X className="w-4 h-4 text-white/50" />
                  </button>
                </div>
                <div className="prose prose-sm prose-invert max-w-none text-indigo-50 leading-relaxed font-medium">
                  <ReactMarkdown>{analysis}</ReactMarkdown>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Marks Table */}
      <div className="bg-white dark:bg-gray-900 rounded-[2rem] border border-gray-100 dark:border-gray-800 shadow-sm overflow-hidden transition-colors mb-12">
        <div className="p-8 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Marks Distribution</h2>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-700 transition-all active:scale-95"
            >
              <Plus className="w-4 h-4" />
              Add Subject
            </button>
            <div className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-sm transition-colors",
              performance.length > 0 && Math.round(performance.reduce((acc, curr) => acc + curr.final, 0) / performance.length) >= 60 ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"
            )}>
              Avg Score: {performance.length > 0 ? Math.round(performance.reduce((acc, curr) => acc + curr.final, 0) / performance.length) : 0}
              {performance.length > 0 && Math.round(performance.reduce((acc, curr) => acc + curr.final, 0) / performance.length) >= 60 ? (
                <TrendingUp className="w-4 h-4" />
              ) : (
                <TrendingDown className="w-4 h-4" />
              )}
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50/50">
                <th className="p-6 text-xs font-bold uppercase tracking-widest text-gray-500 dark:text-gray-400 font-sans">Subject</th>
                <th className="p-6 text-xs font-bold uppercase tracking-widest text-gray-500 dark:text-gray-400 font-sans">CIA 1</th>
                <th className="p-6 text-xs font-bold uppercase tracking-widest text-gray-500 dark:text-gray-400 font-sans">CIA 2</th>
                <th className="p-6 text-xs font-bold uppercase tracking-widest text-gray-500 dark:text-gray-400 font-sans">Sem Result</th>
                <th className="p-6 text-xs font-bold uppercase tracking-widest text-gray-500 dark:text-gray-400 font-sans">Final Avg</th>
                <th className="p-6 text-xs font-bold uppercase tracking-widest text-gray-500 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {performance.map((record, i) => (
                <motion.tr 
                  key={record.subject}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.05 }}
                  className="group hover:bg-gray-50/50 transition-colors"
                >
                  <td className="p-6 font-bold text-gray-900 dark:text-gray-100">
                    {editingId === record.subject ? (
                      <input 
                        type="text"
                        defaultValue={record.subject}
                        autoFocus
                        onBlur={(e) => handleUpdateMark(record.subject, 'subject', e.target.value)}
                        className="w-full p-1 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:border-indigo-500 font-bold dark:text-white"
                      />
                    ) : (
                      record.subject
                    )}
                  </td>
                  <td className="p-6">
                    {editingId === record.subject ? (
                      <input 
                        type="number"
                        defaultValue={record.test1}
                        onChange={(e) => handleUpdateMark(record.subject, 'test1', e.target.value)}
                        className="w-16 p-1 bg-gray-50 dark:bg-gray-800 dark:text-white border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:border-indigo-500 font-medium"
                      />
                    ) : (
                      <span className={cn(
                        "font-bold",
                        record.test1 < 25 ? "text-rose-600" : "text-emerald-600"
                      )}>
                        {record.test1}
                      </span>
                    )}
                  </td>
                  <td className="p-6">
                    {editingId === record.subject ? (
                      <input 
                        type="number"
                        defaultValue={record.test2}
                        onChange={(e) => handleUpdateMark(record.subject, 'test2', e.target.value)}
                        className="w-16 p-1 bg-gray-50 dark:bg-gray-800 dark:text-white border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:border-indigo-500 font-medium"
                      />
                    ) : (
                      <span className={cn(
                        "font-bold",
                        record.test2 < 25 ? "text-rose-600" : "text-emerald-600"
                      )}>
                        {record.test2}
                      </span>
                    )}
                  </td>
                  <td className="p-6">
                    {editingId === record.subject ? (
                      <input 
                        type="number"
                        defaultValue={record.semResult}
                        onChange={(e) => handleUpdateMark(record.subject, 'semResult', e.target.value)}
                        className="w-16 p-1 bg-gray-50 dark:bg-gray-800 dark:text-white border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:border-indigo-500 font-medium"
                      />
                    ) : (
                      <span className="font-bold text-gray-600 dark:text-gray-300">
                        {record.semResult}
                      </span>
                    )}
                  </td>
                  <td className="p-6">
                    <span className={cn(
                      "font-black px-3 py-1 rounded-full text-xs",
                      record.final >= 80 ? "bg-emerald-100 text-emerald-700" : record.final < 60 ? "bg-rose-100 text-rose-700" : "bg-indigo-100 text-indigo-700"
                    )}>
                      {record.final}%
                    </span>
                  </td>
                  <td className="p-6 text-center">
                    <div className="flex items-center justify-center gap-4 relative">
                      <div className="flex items-center gap-1">
                        <button 
                          onClick={() => handleDeleteSubject(record.subject)}
                          className="opacity-0 group-hover:opacity-100 p-2 hover:bg-rose-50 text-rose-300 hover:text-rose-500 rounded-xl transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => setEditingId(editingId === record.subject ? null : record.subject)}
                          className="opacity-0 group-hover:opacity-100 p-2 hover:bg-gray-100 rounded-xl transition-all"
                        >
                          {editingId === record.subject ? <Save className="w-4 h-4 text-emerald-600" /> : <Edit2 className="w-4 h-4 text-gray-400" />}
                        </button>
                      </div>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mini CGPA Calculator */}
      <div className="w-full pb-12">
        <div className="bg-white dark:bg-gray-900 rounded-[3rem] border border-gray-100 dark:border-gray-800 shadow-xl overflow-hidden transition-all">
          <div className="p-10 border-b border-gray-50 dark:border-gray-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 bg-indigo-50/10 dark:bg-indigo-900/10">
            <div className="flex items-center gap-6">
              <div className="p-4 bg-indigo-600 text-white rounded-[1.5rem] shadow-lg shadow-indigo-100 dark:shadow-none">
                <Target className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">CGPA History</h3>
                <p className="text-xs text-gray-500 font-medium">Add all your previous semester results to calculate your accurate CGPA</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4 w-full md:w-auto">
              <div className="flex gap-2">
                <button 
                  onClick={handleSaveAll}
                  disabled={isSaving}
                  className={cn(
                    "p-4 rounded-2xl transition-all flex items-center gap-3 text-[10px] font-black uppercase tracking-widest px-8 shadow-xl active:scale-95",
                    saveSuccess 
                      ? "bg-emerald-600 text-white shadow-emerald-100" 
                      : "bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 text-gray-900 dark:text-white hover:bg-gray-50 shadow-gray-100"
                  )}
                >
                  {isSaving ? (
                    <motion.div 
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                    >
                      <Save className="w-4 h-4" />
                    </motion.div>
                  ) : saveSuccess ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  {saveSuccess ? 'Saved!' : 'Save All'}
                </button>
                <button 
                  onClick={handleAddSemester}
                  className="p-4 bg-indigo-600 text-white rounded-2xl hover:bg-indigo-700 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest px-8 shadow-xl shadow-indigo-100 dark:shadow-none active:scale-95"
                >
                  <Plus className="w-4 h-4" />
                  Add Semester
                </button>
              </div>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50/50 dark:bg-gray-800/30">
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Order</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Semester Name</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Duration / Date</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-gray-400 text-center">Subjects</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-gray-400 text-center">Arrears</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-gray-400">GPA Score</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-gray-400 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                {semesters.slice().reverse().map((sem, i) => (
                  <motion.tr
                    key={sem.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="group hover:bg-gray-50/30 dark:hover:bg-gray-800/20 transition-colors"
                  >
                    <td className="p-6">
                      <div className="w-10 h-10 bg-gray-50 dark:bg-gray-800 rounded-xl flex items-center justify-center font-black text-xs text-gray-400">
                        {sem.id}
                      </div>
                    </td>
                    <td className="p-6">
                      <input 
                        type="text"
                        value={sem.name}
                        onChange={(e) => handleUpdateSemester(sem.id, 'name', e.target.value)}
                        placeholder="e.g. Semester 1"
                        className="bg-transparent font-bold text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/10 rounded-lg px-2 py-1 w-full border border-transparent hover:border-gray-200 dark:hover:border-gray-700 transition-all"
                      />
                    </td>
                    <td className="p-6">
                      <input 
                        type="text"
                        value={sem.date}
                        onChange={(e) => handleUpdateSemester(sem.id, 'date', e.target.value)}
                        placeholder="e.g. Jan-May 2025"
                        className="bg-transparent font-medium text-gray-500 dark:text-gray-400 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/10 rounded-lg px-2 py-1 w-full border border-transparent hover:border-gray-200 dark:hover:border-gray-700 transition-all"
                      />
                    </td>
                    <td className="p-6 text-center">
                      <input 
                        type="number"
                        value={sem.subjects}
                        onChange={(e) => handleUpdateSemester(sem.id, 'subjects', e.target.value)}
                        className="w-16 p-2 bg-transparent text-gray-600 dark:text-gray-300 font-bold text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/10 rounded-lg border border-transparent hover:border-gray-200 dark:hover:border-gray-700 transition-all text-center"
                      />
                    </td>
                    <td className="p-6 text-center">
                      <input 
                        type="number"
                        value={sem.arrears || 0}
                        onChange={(e) => handleUpdateSemester(sem.id, 'arrears', e.target.value)}
                        className="w-16 p-2 bg-transparent text-rose-600 font-black text-sm focus:outline-none focus:ring-2 focus:ring-rose-500/10 rounded-lg border border-transparent hover:border-gray-200 dark:hover:border-gray-700 transition-all text-center"
                      />
                    </td>
                    <td className="p-6">
                      <div className="flex items-center gap-3">
                        <input 
                          type="number"
                          step="0.01"
                          min="0"
                          max="10"
                          value={sem.gpa}
                          onChange={(e) => handleUpdateSemester(sem.id, 'gpa', e.target.value)}
                          className="w-20 p-2 bg-indigo-50/50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-800 rounded-xl text-lg font-black text-indigo-600 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all tabular-nums"
                        />
                        <div className={cn(
                          "w-2 h-2 rounded-full",
                          sem.gpa >= 9 ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" : 
                          sem.gpa >= 8 ? "bg-indigo-500" :
                          sem.gpa >= 7 ? "bg-amber-500" : "bg-rose-500"
                        )} />
                      </div>
                    </td>
                    <td className="p-6">
                      <div className="flex justify-center items-center gap-2">
                        <button 
                          onClick={handleSaveAll}
                          className="p-3 text-gray-300 hover:text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-900/10 rounded-2xl transition-all opacity-0 group-hover:opacity-100 focus:opacity-100"
                        >
                          <Save className="w-5 h-5" />
                        </button>
                        <button 
                          onClick={() => setSemesters(prev => prev.filter(s => s.id !== sem.id))}
                          className="p-3 text-gray-300 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/10 rounded-2xl transition-all opacity-0 group-hover:opacity-100 focus:opacity-100"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
            {semesters.length === 0 && (
              <div className="py-24 text-center space-y-4">
                <div className="w-16 h-16 bg-gray-50 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto text-gray-300">
                  <Calculator className="w-8 h-8" />
                </div>
                <div className="space-y-1">
                  <p className="text-gray-900 dark:text-white font-bold">No semesters found</p>
                  <p className="text-sm text-gray-500">Add your previous results to start the calculation</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Grade Point Calculator */}
      <div className="w-full pb-12">
        <div className="bg-white dark:bg-gray-900 rounded-[3rem] border border-gray-100 dark:border-gray-800 shadow-xl overflow-hidden">
          <div className="p-8 border-b border-gray-50 dark:border-gray-800 bg-emerald-50/10 dark:bg-emerald-900/10 flex items-center gap-4">
            <div className="p-3 bg-emerald-600 text-white rounded-2xl">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white">Quick Grade Calculator</h3>
              <p className="text-xs text-gray-500 font-medium">Select grades to calculate total points instantly</p>
            </div>
          </div>
          
          <div className="p-8">
            <GradeCalculator onSave={handleSaveCalculatedGpa} />
          </div>
        </div>
      </div>

      {/* Add Subject Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-gray-900/40 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white dark:bg-gray-900 w-full max-w-sm rounded-[3rem] shadow-2xl overflow-hidden border border-white/20 dark:border-gray-800"
            >
              <div className="p-8 bg-emerald-600 text-white relative">
                <div className="flex justify-between items-start relative z-10">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-white/20 backdrop-blur-xl rounded-2xl border border-white/30">
                      <Plus className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-100 mb-1">Performance</p>
                      <h3 className="font-black text-2xl tracking-tight">New Subject</h3>
                    </div>
                  </div>
                  <button onClick={() => setShowAddModal(false)} className="p-2 bg-white/10 hover:bg-white/20 rounded-full transition-all">
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="p-8 space-y-6">
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-1">Subject Name</label>
                  <input 
                    autoFocus
                    type="text" 
                    placeholder="e.g. Physics"
                    value={newSubjectName}
                    onChange={(e) => setNewSubjectName(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddSubject()}
                    className="w-full p-5 bg-gray-50 dark:bg-gray-800 border-2 border-gray-100 dark:border-gray-700 rounded-3xl focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-400/50 transition-all font-bold text-gray-700 dark:text-white text-sm"
                  />
                </div>

                <div className="pt-2">
                  <button 
                    onClick={handleAddSubject}
                    className="w-full bg-emerald-600 text-white py-5 rounded-[2rem] font-black uppercase tracking-[0.2em] hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-200 flex items-center justify-center gap-3 group text-[11px]"
                  >
                    Add Subject
                    <Plus className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
