import React, { useState } from 'react';
import { User, Mail, BookOpen, GraduationCap, Calendar, MapPin, Share2, Edit3, Save, X } from 'lucide-react';
import { useUser } from '../context/UserContext';

export default function Profile() {
  const { user, updateUser } = useUser();
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState(user);

  const handleSave = () => {
    updateUser(editForm);
    setIsEditing(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="relative h-80 rounded-[4rem] bg-indigo-600 overflow-hidden shadow-2xl flex flex-col items-center justify-center border-b-8 border-indigo-500/20">
        {/* Ultra Premium Modern Mesh Gradient */}
        <div className="absolute inset-0 bg-indigo-600" />
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_20%_30%,#4F46E5_0%,transparent_50%),radial-gradient(circle_at_80%_70%,#7C3AED_0%,transparent_50%),radial-gradient(circle_at_50%_10%,#818CF8_0%,transparent_40%),radial-gradient(circle_at_90%_20%,#C084FC_0%,transparent_30%)] opacity-80" />
        <div className="absolute inset-0 bg-black/5 backdrop-blur-[2px]" />
        
        {/* Decorative elements */}
        <div className="absolute top-10 left-10 w-32 h-32 bg-white/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-10 right-10 w-48 h-48 bg-purple-400/20 rounded-full blur-3xl animate-pulse delay-700" />

        <div className="relative p-2.5 bg-white/10 backdrop-blur-3xl rounded-full shadow-2xl z-10 transform transition-all hover:scale-105 duration-700 border border-white/20">
          <div className="w-48 h-48 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center border-[8px] border-white dark:border-gray-950 overflow-hidden shadow-2xl relative group">
            {user.profilePic ? (
              <img 
                src={user.profilePic} 
                alt={user.name} 
                className="w-full h-full object-cover transform transition-transform duration-700 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
            ) : (
              <User className="w-20 h-20 text-gray-300" />
            )}
            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
              <span className="text-white text-[10px] font-black uppercase tracking-widest">Active Profile</span>
            </div>
          </div>
        </div>
        <button className="absolute top-6 right-8 p-3 bg-white/20 backdrop-blur-md rounded-2xl text-white hover:bg-white/30 transition-all">
          <Share2 className="w-5 h-5" />
        </button>
      </header>

      <div className="grid md:grid-cols-[1fr_2fr] gap-8">
        <aside className="space-y-6">
          <div className="space-y-2 text-center">
            {isEditing ? (
              <input 
                type="text"
                value={editForm.name}
                onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                className="text-3xl font-black text-gray-900 dark:text-white tracking-tight bg-gray-50 dark:bg-gray-800 border-2 border-indigo-100 dark:border-indigo-900/50 rounded-xl px-2 w-full focus:outline-none focus:border-indigo-400 text-center"
              />
            ) : (
              <h1 className="text-3xl font-black text-gray-900 dark:text-white tracking-tight">{user.name}</h1>
            )}
            {isEditing ? (
              <input 
                type="text"
                value={editForm.course}
                onChange={(e) => setEditForm({ ...editForm, course: e.target.value })}
                className="text-indigo-600 dark:text-indigo-400 font-bold uppercase tracking-[0.2em] text-xs bg-gray-50 dark:bg-gray-800 border border-indigo-100 dark:border-indigo-900/50 rounded-lg px-2 w-full mt-1 focus:outline-none focus:border-indigo-400 text-center"
              />
            ) : (
              <p className="text-indigo-600 dark:text-indigo-400 font-bold uppercase tracking-[0.2em] text-xs">{user.course}</p>
            )}
          </div>

          <div className="bg-white dark:bg-gray-900 p-6 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-xl space-y-4 transition-colors text-center">
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-50 dark:border-gray-800 pb-2">Profile Actions</h3>
            {isEditing && (
              <div className="space-y-4 pt-2">
                <div className="text-left">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-1">Profile Image URL</label>
                  <input 
                    type="text"
                    placeholder="Paste image URL here"
                    value={editForm.profilePic || ''}
                    onChange={(e) => setEditForm({ ...editForm, profilePic: e.target.value })}
                    className="text-xs font-bold text-gray-800 dark:text-gray-100 bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-800 rounded-xl px-3 py-2 w-full focus:outline-none focus:border-indigo-400"
                  />
                </div>
              </div>
            )}
            {isEditing ? (
              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={handleSave}
                  className="bg-indigo-600 text-white p-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all active:scale-[0.98]"
                >
                  <Save className="w-4 h-4" />
                  Save
                </button>
                <button 
                  onClick={() => setIsEditing(false)}
                  className="bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 p-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-gray-200 dark:hover:bg-gray-700 transition-all active:scale-[0.98]"
                >
                  <X className="w-4 h-4" />
                  Cancel
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setIsEditing(true)}
                className="w-full bg-gray-900 dark:bg-black text-white p-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-black dark:hover:bg-gray-900 transition-all active:scale-[0.98]"
              >
                <Edit3 className="w-4 h-4" />
                Edit Profile
              </button>
            )}
          </div>
        </aside>

        <section className="bg-white dark:bg-gray-900 p-8 rounded-[2.5rem] border border-gray-100 dark:border-gray-800 shadow-xl space-y-8 transition-colors">
          <div className="grid sm:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-gray-400">Academic Details</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-lg">
                    <GraduationCap className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Enrollment</p>
                    {isEditing ? (
                      <input 
                        type="text"
                        value={editForm.rollNo || ''}
                        onChange={(e) => setEditForm({ ...editForm, rollNo: e.target.value })}
                        className="text-sm font-bold text-gray-800 dark:text-gray-100 bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-800 rounded px-1 w-full"
                      />
                    ) : (
                      <p className="text-sm font-bold text-gray-800 dark:text-gray-200">{user.rollNo || '22CSE001'}</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-lg">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Academic Year</p>
                    {isEditing ? (
                      <input 
                        type="text"
                        value={editForm.year || ''}
                        onChange={(e) => setEditForm({ ...editForm, year: e.target.value })}
                        className="text-sm font-bold text-gray-800 dark:text-gray-100 bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-800 rounded px-1 w-full"
                      />
                    ) : (
                      <p className="text-sm font-bold text-gray-800 dark:text-gray-200">{user.year}</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-lg">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Section</p>
                    {isEditing ? (
                      <input 
                        type="text"
                        value={editForm.section || ''}
                        onChange={(e) => setEditForm({ ...editForm, section: e.target.value })}
                        className="text-sm font-bold text-gray-800 dark:text-gray-100 bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-800 rounded px-1 w-full"
                      />
                    ) : (
                      <p className="text-sm font-bold text-gray-800 dark:text-gray-200">CSE Section - {user.section || 'C'}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-gray-400">Contact Info</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-lg">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Email Address</p>
                    {isEditing ? (
                      <input 
                        type="email"
                        value={editForm.email}
                        onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                        className="text-sm font-bold text-gray-800 dark:text-gray-100 bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-800 rounded px-1 w-full"
                      />
                    ) : (
                      <p className="text-sm font-bold text-gray-800 dark:text-gray-200">{user.email}</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-lg">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Campus</p>
                    {isEditing ? (
                      <input 
                        type="text"
                        value={editForm.campus || ''}
                        onChange={(e) => setEditForm({ ...editForm, campus: e.target.value })}
                        className="text-sm font-bold text-gray-800 dark:text-gray-100 bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-800 rounded px-1 w-full"
                      />
                    ) : (
                      <p className="text-sm font-bold text-gray-800 dark:text-gray-200">{user.campus || 'Main Tech Campus'}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-gray-50 dark:border-gray-800 flex items-center justify-between transition-colors">
            <div className="text-center flex-1">
              <p className="text-2xl font-black text-gray-900 dark:text-white">{user.cgpa}</p>
              <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">CGPA</p>
            </div>
            <div className="w-px h-10 bg-gray-100 dark:bg-gray-800" />
            <div className="text-center flex-1">
              <p className="text-2xl font-black text-gray-900 dark:text-white">{user.arrears || 0}</p>
              <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Arrears</p>
            </div>
            <div className="w-px h-10 bg-gray-100 dark:bg-gray-800" />
            <div className="text-center flex-1">
              <p className="text-2xl font-black text-gray-900 dark:text-white">88%</p>
              <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Attendance</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
