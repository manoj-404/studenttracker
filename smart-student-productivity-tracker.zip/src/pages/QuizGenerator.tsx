import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Brain, Sparkles, Loader2, Play, CheckCircle2, XCircle } from 'lucide-react';
import { generateQuiz } from '../services/geminiService';
import { cn } from '../lib/utils';

interface Question {
  question: string;
  options: string[];
  answer: string;
}

export default function QuizGenerator() {
  const [topic, setTopic] = useState('');
  const [quiz, setQuiz] = useState<Question[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState<'input' | 'quiz' | 'result'>('input');
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [score, setScore] = useState(0);

  const handleGenerate = async () => {
    if (!topic.trim() || isLoading) return;
    setIsLoading(true);
    setError(null);
    try {
      const data = await generateQuiz(topic);
      if (Array.isArray(data)) {
        setQuiz(data);
        setCurrentStep('quiz');
        setUserAnswers({});
      } else {
        throw new Error('Invalid quiz format received from AI');
      }
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'Failed to generate quiz. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = () => {
    let finalScore = 0;
    quiz.forEach((q, i) => {
      if (userAnswers[i] === q.answer) finalScore++;
    });
    setScore(finalScore);
    setCurrentStep('result');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="text-center space-y-2">
        <div className="inline-flex p-3 bg-fuchsia-100 dark:bg-fuchsia-900/30 text-fuchsia-600 dark:text-fuchsia-400 rounded-2xl mb-2">
          <Brain className="w-8 h-8" />
        </div>
        <h1 className="text-4xl font-black text-gray-900 dark:text-white tracking-tight">AI Quiz Generator</h1>
        <p className="text-gray-500 dark:text-gray-400 font-medium">Test your knowledge on any topic instantly.</p>
      </header>

      <AnimatePresence mode="wait">
        {currentStep === 'input' && (
          <motion.div
            key="input"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white dark:bg-gray-900 p-8 rounded-[2.5rem] border border-gray-100 dark:border-gray-800 shadow-2xl shadow-fuchsia-900/5 space-y-6 transition-colors"
          >
            <div className="space-y-4">
              <label className="block text-sm font-black uppercase tracking-[0.2em] text-gray-400">Enter Topic</label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g. Java OOP, World War II, Quantum Physics..."
                className="w-full text-2xl font-bold bg-gray-50 dark:bg-gray-800 border-2 border-transparent focus:border-fuchsia-500 focus:bg-white dark:focus:bg-gray-800 rounded-3xl p-6 transition-all focus:outline-none dark:text-white"
              />
            </div>
            <button
              onClick={handleGenerate}
              disabled={!topic.trim() || isLoading}
              className="w-full bg-fuchsia-600 text-white p-6 rounded-3xl font-black text-xl flex items-center justify-center gap-3 hover:bg-fuchsia-700 transition-all shadow-xl shadow-fuchsia-200 dark:shadow-none active:scale-[0.98] disabled:opacity-50"
            >
              {isLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Sparkles className="w-6 h-6" />}
              Generate Quiz
            </button>

            {error && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="p-4 bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 rounded-2xl text-center font-bold text-sm border border-rose-100 dark:border-rose-900/50"
              >
                {error}
              </motion.div>
            )}
          </motion.div>
        )}

        {currentStep === 'quiz' && (
          <motion.div
            key="quiz"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="space-y-8"
          >
            {quiz.map((q, qIdx) => (
              <div key={qIdx} className="bg-white dark:bg-gray-900 p-8 rounded-[2rem] border border-gray-100 dark:border-gray-800 shadow-xl space-y-6 transition-colors">
                <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 leading-snug">
                  {qIdx + 1}. {q.question}
                </h3>
                <div className="grid gap-3">
                  {q.options.map((opt, optIdx) => (
                    <button
                      key={optIdx}
                      onClick={() => setUserAnswers(prev => ({ ...prev, [qIdx]: opt }))}
                      className={cn(
                        "w-full text-left p-5 rounded-2xl border-2 transition-all font-bold",
                        userAnswers[qIdx] === opt 
                          ? "bg-fuchsia-600 border-fuchsia-600 text-white shadow-lg shadow-fuchsia-100 dark:shadow-none" 
                          : "bg-gray-50 dark:bg-gray-800 border-transparent text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                      )}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            ))}
            <button
              onClick={handleSubmit}
              disabled={Object.keys(userAnswers).length < quiz.length}
              className="w-full bg-gray-900 dark:bg-fuchsia-600 text-white p-6 rounded-3xl font-black text-xl hover:bg-black dark:hover:bg-fuchsia-700 transition-all shadow-xl active:scale-[0.98] disabled:opacity-20"
            >
              Submit Quiz
            </button>
          </motion.div>
        )}

        {currentStep === 'result' && (
          <motion.div
            key="result"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-gray-900 p-12 rounded-[3rem] border-4 border-gray-100 dark:border-gray-800 shadow-2xl text-center space-y-8 transition-colors"
          >
            <div className="space-y-2">
              <h2 className="text-2xl font-black uppercase tracking-widest text-gray-400">Your Score</h2>
              <div className="text-8xl font-black text-fuchsia-600 tabular-nums">
                {score}<span className="text-3xl text-gray-300 dark:text-gray-700">/{quiz.length}</span>
              </div>
            </div>
            
            <div className="space-y-4 max-h-[400px] overflow-y-auto px-4">
              {quiz.map((q, i) => (
                <div key={i} className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800 text-left">
                  {userAnswers[i] === q.answer ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0" />
                  ) : (
                    <XCircle className="w-6 h-6 text-rose-500 shrink-0" />
                  )}
                  <div>
                    <p className="font-bold text-sm text-gray-800 dark:text-gray-100">{q.question}</p>
                    <p className="text-xs text-gray-500">Correct: <span className="text-emerald-600 dark:text-emerald-400">{q.answer}</span></p>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => setCurrentStep('input')}
              className="w-full bg-fuchsia-600 text-white p-6 rounded-3xl font-black text-xl hover:bg-fuchsia-700 transition-all"
            >
              Take Another Quiz
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
