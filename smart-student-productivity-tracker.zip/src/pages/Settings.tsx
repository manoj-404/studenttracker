import React, { useState } from 'react';
import { Moon, Bell, Lock, Globe, Shield, HelpCircle, ChevronRight, Sun, Eye, EyeOff, Check, X } from 'lucide-react';
import { cn } from '../lib/utils';
import { useTheme } from '../context/ThemeContext';
import { motion, AnimatePresence } from 'motion/react';

const LANGUAGES = [
  { code: 'en', name: 'English (US)', flag: '🇺🇸' },
  { code: 'hi', name: 'Hindi', flag: '🇮🇳' },
  { code: 'te', name: 'Telugu', flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', flag: '🇮🇳' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
];

export default function Settings() {
  const { theme, toggleTheme } = useTheme();
  const [notifications, setNotifications] = useState(true);
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [language, setLanguage] = useState('en');
  const [showLanguageList, setShowLanguageList] = useState(false);
  const [showCurrentPass, setShowCurrentPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);

  const darkMode = theme === 'dark';

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      <header>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight">Settings</h1>
        <p className="text-gray-500 dark:text-gray-400 font-medium tracking-tight">Manage your account preferences and app behavior.</p>
        <div className="mt-4 p-4 bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-800 rounded-2xl">
          <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest leading-relaxed">
            Note: You should maintain 8 hours of focus daily to reach your targets.
          </p>
        </div>
      </header>

      <div className="space-y-6">
        <section className="bg-white dark:bg-gray-900 rounded-[2rem] border border-gray-100 dark:border-gray-800 shadow-xl divide-y divide-gray-50 dark:divide-gray-800 overflow-hidden transition-colors">
          <div className="p-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-2xl">
                {darkMode ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
              </div>
              <div>
                <h3 className="font-bold text-gray-900 dark:text-white">Dark Mode</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">Adjust appearance for low light</p>
              </div>
            </div>
            <button 
              onClick={toggleTheme}
              className={cn(
                "w-12 h-6 rounded-full transition-all relative",
                darkMode ? "bg-indigo-600" : "bg-gray-200"
              )}
            >
              <div className={cn(
                "absolute top-1 w-4 h-4 rounded-full bg-white transition-all",
                darkMode ? "left-7" : "left-1"
              )} />
            </button>
          </div>

          <div className="p-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-2xl">
                <Bell className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 dark:text-white">Push Notifications</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">Get real-time updates</p>
              </div>
            </div>
            <button 
              onClick={() => setNotifications(!notifications)}
              className={cn(
                "w-12 h-6 rounded-full transition-all relative",
                notifications ? "bg-indigo-600" : "bg-gray-200"
              )}
            >
              <div className={cn(
                "absolute top-1 w-4 h-4 rounded-full bg-white transition-all",
                notifications ? "left-7" : "left-1"
              )} />
            </button>
          </div>
        </section>

        <section className="bg-white dark:bg-gray-900 rounded-[2rem] border border-gray-100 dark:border-gray-800 shadow-xl overflow-hidden transition-colors">
          <div className="divide-y divide-gray-50 dark:divide-gray-800">
            {/* Password Section */}
            <div className="w-full">
              <button 
                onClick={() => setShowPasswordForm(!showPasswordForm)}
                className="w-full p-6 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-800 transition-all text-left"
              >
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-2xl">
                    <Lock className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 dark:text-white">Change Password</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">Update your security credentials</p>
                  </div>
                </div>
                <ChevronRight className={cn("w-5 h-5 text-gray-300 dark:text-gray-600 transition-transform", showPasswordForm && "rotate-90")} />
              </button>

              <AnimatePresence>
                {showPasswordForm && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden bg-gray-50/50 dark:bg-gray-800/30"
                  >
                    <div className="p-8 space-y-5">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Current Password</label>
                        <div className="relative">
                          <input 
                            type={showCurrentPass ? "text" : "password"}
                            placeholder="••••••••"
                            className="w-full p-4 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600 transition-all font-mono"
                          />
                          <button 
                            type="button"
                            onClick={() => setShowCurrentPass(!showCurrentPass)}
                            className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"
                          >
                            {showCurrentPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">New Password</label>
                          <div className="relative">
                            <input 
                              type={showNewPass ? "text" : "password"}
                              placeholder="••••••••"
                              className="w-full p-4 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600 transition-all font-mono"
                            />
                            <button 
                              type="button"
                              onClick={() => setShowNewPass(!showNewPass)}
                              className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"
                            >
                              {showNewPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          {['Upper', 'Special', '8+ Char'].map(req => (
                            <div key={req} className="flex items-center gap-1 text-[10px] font-bold text-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 px-2 py-1 rounded-md">
                              <Check className="w-2.5 h-2.5" />
                              {req}
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="flex gap-3 pt-2">
                        <button className="flex-1 bg-indigo-600 text-white font-black uppercase tracking-widest text-[10px] py-4 rounded-2xl shadow-xl shadow-indigo-100 dark:shadow-none hover:bg-indigo-700 transition-all">
                          Update Password
                        </button>
                        <button 
                          onClick={() => setShowPasswordForm(false)}
                          className="px-6 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 text-gray-500 font-black uppercase tracking-widest text-[10px] rounded-2xl hover:bg-gray-50 dark:hover:bg-gray-800 transition-all"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Language Section */}
            <div className="w-full">
              <button 
                onClick={() => setShowLanguageList(!showLanguageList)}
                className="w-full p-6 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-800 transition-all text-left"
              >
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-2xl">
                    <Globe className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 dark:text-white">Language</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                      {LANGUAGES.find(l => l.code === language)?.name}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-lg">{LANGUAGES.find(l => l.code === language)?.flag}</span>
                  <ChevronRight className={cn("w-5 h-5 text-gray-300 dark:text-gray-600 transition-transform", showLanguageList && "rotate-90")} />
                </div>
              </button>

              <AnimatePresence>
                {showLanguageList && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden bg-gray-50/50 dark:bg-gray-800/30 px-6 py-4"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {LANGUAGES.map((lang) => (
                        <button
                          key={lang.code}
                          onClick={() => {
                            setLanguage(lang.code);
                            setShowLanguageList(false);
                          }}
                          className={cn(
                            "flex items-center justify-between p-4 rounded-2xl border transition-all",
                            language === lang.code 
                              ? "bg-white dark:bg-gray-900 border-indigo-600 shadow-lg shadow-indigo-100 dark:shadow-none" 
                              : "bg-transparent border-transparent hover:bg-white dark:hover:bg-gray-900 hover:border-gray-100 dark:hover:border-gray-800"
                          )}
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-xl">{lang.flag}</span>
                            <span className={cn("text-sm font-bold", language === lang.code ? "text-indigo-600" : "text-gray-600 dark:text-gray-400")}>
                              {lang.name}
                            </span>
                          </div>
                          {language === lang.code && <Check className="w-4 h-4 text-indigo-600" />}
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </section>

        <section className="bg-white dark:bg-gray-900 rounded-[2rem] border border-gray-100 dark:border-gray-800 shadow-xl divide-y divide-gray-50 dark:divide-gray-800 overflow-hidden transition-colors">
          <button className="w-full p-6 flex items-center gap-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-all text-left">
            <div className="p-3 bg-gray-50 dark:bg-gray-800 text-gray-400 rounded-2xl">
              <Shield className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-gray-900 dark:text-white">Privacy Policy</h3>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-300 dark:text-gray-600" />
          </button>
          <button className="w-full p-6 flex items-center gap-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-all text-left">
            <div className="p-3 bg-gray-50 dark:bg-gray-800 text-gray-400 rounded-2xl">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-gray-900 dark:text-white">Help & Support</h3>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-300 dark:text-gray-600" />
          </button>
        </section>

        <footer className="text-center pt-4">
          <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Version 2.4.0 (Active Build)</p>
        </footer>
      </div>
    </div>
  );
}
