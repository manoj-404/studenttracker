import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Calendar, Sparkles, Loader2, Clock, CheckCircle } from 'lucide-react';
import { generateStudyPlan } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';

export default function StudyPlanner() {
  const [input, setInput] = useState('');
  const [plan, setPlan] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = async () => {
    if (!input.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const res = await generateStudyPlan(input);
      setPlan(res || '');
    } catch (error) {
      console.error(error);
      setPlan('Failed to generate study plan.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight">AI Study Planner</h1>
          <p className="text-gray-500 dark:text-gray-400 font-medium tracking-tight">Personalized schedules to crush your goals.</p>
        </div>
      </header>

      <div className="grid lg:grid-cols-[1fr_2fr] gap-8">
        <aside className="space-y-6">
          <div className="bg-white dark:bg-gray-900 p-6 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-xl space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest">Plan Details</label>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="e.g. I have a Java exam in 7 days, I need to cover OOP and Exceptions."
                className="w-full h-40 p-4 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all font-medium text-sm leading-relaxed dark:text-gray-100"
              />
            </div>
            <button
              onClick={handleGenerate}
              disabled={!input.trim() || isLoading}
              className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all active:scale-[0.98] disabled:opacity-50"
            >
              {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
              Generate Plan
            </button>
          </div>

          <div className="bg-gradient-to-br from-indigo-600 to-violet-700 p-6 rounded-3xl text-white shadow-xl shadow-indigo-100">
            <h3 className="font-bold mb-2 flex items-center gap-2">
              <CheckCircle className="w-5 h-5" />
              Pro Tip
            </h3>
            <p className="text-xs text-indigo-100 leading-relaxed font-medium">
              Be specific about the topics you find difficult. The AI will allocate more time to them to ensure you're fully prepared.
            </p>
          </div>
        </aside>

        <section className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-xl overflow-hidden min-h-[500px]">
          <div className="bg-gray-50 dark:bg-gray-800/50 border-b border-gray-100 dark:border-gray-800 px-6 py-4 flex items-center gap-3">
            <Calendar className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <h2 className="font-bold text-sm uppercase tracking-widest text-gray-700 dark:text-gray-300">Your AI Study Schedule</h2>
          </div>
          
          <div className="p-8">
            {isLoading ? (
              <div className="h-full py-20 flex flex-col items-center justify-center text-gray-400 space-y-4">
                <Loader2 className="w-12 h-12 animate-spin text-indigo-600" />
                <p className="text-lg font-bold dark:text-white">Crafting your success plan...</p>
              </div>
            ) : plan ? (
              <div className="prose prose-sm prose-indigo dark:prose-invert max-w-none prose-headings:mb-2 prose-headings:mt-6 prose-p:leading-relaxed">
                <ReactMarkdown>{plan}</ReactMarkdown>
              </div>
            ) : (
              <div className="h-full py-20 flex flex-col items-center justify-center text-gray-300 dark:text-gray-600 space-y-4">
                <div className="w-16 h-16 bg-gray-50 dark:bg-gray-800 rounded-full flex items-center justify-center">
                  <Calendar className="w-8 h-8" />
                </div>
                <p className="text-sm font-medium text-center px-20">
                  Fill in your exam details and goals to see your personalized study plan here.
                </p>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
