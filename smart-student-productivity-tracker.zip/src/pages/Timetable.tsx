import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { DUMMY_TIMETABLE as INITIAL_TIMETABLE } from '../constants';
import { cn } from '../lib/utils';
import { StickyNote, X, ChevronRight, Settings, Save, Trash2, Plus, Check, ChevronLeft, Calendar } from 'lucide-react';

export default function Timetable() {
  const [timetable, setTimetable] = useState(INITIAL_TIMETABLE);
  const [selectedSlot, setSelectedSlot] = useState<{ day: string, hour: number, subject: string, homework?: string } | null>(null);
  const [isCustomizing, setIsCustomizing] = useState(false);
  const [editingSlot, setEditingSlot] = useState<{ day: string, hour: number, subject: string, color?: string } | null>(null);
  const [currentTheme, setCurrentTheme] = useState<'default' | 'cyber' | 'royal' | 'forest'>('default');
  const [attendance, setAttendance] = useState<Record<string, number>>({
    "MATHS": 85,
    "DSA": 80,
    "WEB": 90,
    "AJP": 75,
    "ENGLISH": 82,
    "TAMIL": 88,
    "PSYCHOLOGY": 78
  });

  // Daily calendar state for marking present or absent for the entire day
  const [dailyAttendance, setDailyAttendance] = useState<Record<string, 'present' | 'absent'>>(() => {
    try {
      const saved = localStorage.getItem('timetable_daily_attendance');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const today = new Date();
  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [selectedCalDate, setSelectedCalDate] = useState<string>(() => {
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, '0');
    const d = String(today.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  });

  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const updateDailyAttendance = (dateStr: string, status: 'present' | 'absent' | 'none') => {
    setDailyAttendance(prev => {
      const next = { ...prev };
      if (status === 'none') {
        delete next[dateStr];
      } else {
        next[dateStr] = status;
      }
      localStorage.setItem('timetable_daily_attendance', JSON.stringify(next));
      return next;
    });
  };

  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };

  const daysInMonth = getDaysInMonth(currentYear, currentMonth);
  const firstDay = getFirstDayOfMonth(currentYear, currentMonth);

  // Generate complete grid with padding
  const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
  const prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;
  const daysInPrevMonth = getDaysInMonth(prevYear, prevMonth);

  const calendarCellsWithPadding = [];
  // Add previous month's ending days
  for (let i = firstDay - 1; i >= 0; i--) {
    calendarCellsWithPadding.push({
      day: daysInPrevMonth - i,
      month: prevMonth,
      year: prevYear,
      isCurrentMonth: false
    });
  }
  // Add current month's days
  for (let day = 1; day <= daysInMonth; day++) {
    calendarCellsWithPadding.push({
      day,
      month: currentMonth,
      year: currentYear,
      isCurrentMonth: true
    });
  }
  // Add next month's beginning days
  const totalCells = Math.ceil(calendarCellsWithPadding.length / 7) * 7;
  const nextMonth = currentMonth === 11 ? 0 : currentMonth + 1;
  const nextYear = currentMonth === 11 ? currentYear + 1 : currentYear;
  const neededCells = totalCells - calendarCellsWithPadding.length;
  for (let day = 1; day <= neededCells; day++) {
    calendarCellsWithPadding.push({
      day,
      month: nextMonth,
      year: nextYear,
      isCurrentMonth: false
    });
  }

  const formatDateString = (year: number, month: number, day: number) => {
    const y = year;
    const m = String(month + 1).padStart(2, '0');
    const d = String(day).padStart(2, '0');
    return `${y}-${m}-${d}`;
  };

  const getReadableDate = (dateStr: string) => {
    const [y, mStr, dStr] = dateStr.split('-');
    const m = parseInt(mStr) - 1;
    const val = new Date(parseInt(y), m, parseInt(dStr));
    return val.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  };

  const monthStats = (() => {
    let present = 0;
    let absent = 0;
    Object.entries(dailyAttendance).forEach(([dateStr, status]) => {
      const [y, mStr] = dateStr.split('-');
      const m = parseInt(mStr) - 1;
      const year = parseInt(y);
      if (year === currentYear && m === currentMonth) {
        if (status === 'present') present++;
        else if (status === 'absent') absent++;
      }
    });

    const total = present + absent;
    const percentage = total > 0 ? Math.round((present / total) * 105) : 100;
    const cappedPercentage = Math.min(100, percentage);

    return { present, absent, total, percentage: cappedPercentage };
  })();

  const calendarThemes = {
    default: {
      cardBg: "bg-white dark:bg-gray-800",
      border: "border-violet-100 dark:border-gray-700",
      text: "text-gray-800 dark:text-gray-100",
      accent: "bg-indigo-600 text-white",
      accentText: "text-indigo-600 dark:text-indigo-400",
      hoverBg: "hover:bg-violet-50 dark:hover:bg-gray-700",
      activeDayRing: "ring-2 ring-indigo-500 ring-offset-2 dark:ring-offset-gray-800",
      btnPresent: "bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/60 dark:text-emerald-400 dark:border-emerald-800",
      btnAbsent: "bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:hover:bg-rose-900/60 dark:text-rose-400 dark:border-rose-800",
      btnClear: "bg-gray-50 hover:bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-800/60 dark:hover:bg-gray-700 dark:text-gray-300 dark:border-gray-700",
    },
    cyber: {
      cardBg: "bg-slate-900 border-slate-850",
      border: "border-cyan-500/20",
      text: "text-slate-100",
      accent: "bg-cyan-600 text-white",
      accentText: "text-cyan-400",
      hoverBg: "hover:bg-slate-800",
      activeDayRing: "ring-2 ring-cyan-500 ring-offset-2 ring-offset-slate-900",
      btnPresent: "bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
      btnAbsent: "bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border-rose-500/30",
      btnClear: "bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700",
    },
    royal: {
      cardBg: "bg-white dark:bg-gray-800",
      border: "border-rose-100 dark:border-gray-700",
      text: "text-gray-800 dark:text-gray-100",
      accent: "bg-rose-600 text-white",
      accentText: "text-rose-600 dark:text-rose-400",
      hoverBg: "hover:bg-rose-50/50 dark:hover:bg-gray-700",
      activeDayRing: "ring-2 ring-rose-500 ring-offset-2 dark:ring-offset-gray-800",
      btnPresent: "bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/60 dark:text-emerald-400 dark:border-emerald-800",
      btnAbsent: "bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:hover:bg-rose-900/60 dark:text-rose-400 dark:border-rose-800",
      btnClear: "bg-gray-50 hover:bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-800/60 dark:hover:bg-gray-700 dark:text-gray-300 dark:border-gray-700",
    },
    forest: {
      cardBg: "bg-white dark:bg-gray-800",
      border: "border-emerald-100 dark:border-gray-700",
      text: "text-gray-800 dark:text-gray-100",
      accent: "bg-emerald-600 text-white",
      accentText: "text-emerald-600 dark:text-emerald-400",
      hoverBg: "hover:bg-emerald-50/50 dark:hover:bg-gray-700",
      activeDayRing: "ring-2 ring-emerald-500 ring-offset-2 dark:ring-offset-gray-800",
      btnPresent: "bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/60 dark:text-emerald-400 dark:border-emerald-800",
      btnAbsent: "bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:hover:bg-rose-900/60 dark:text-rose-400 dark:border-rose-800",
      btnClear: "bg-gray-50 hover:bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-800/60 dark:hover:bg-gray-700 dark:text-gray-300 dark:border-gray-700",
    }
  };

  const calTheme = calendarThemes[currentTheme];

  const getSubjectAttendance = (subject: string) => {
    // Normalize subject name for matching
    const upperSub = subject.toUpperCase();
    if (upperSub.includes('MATH')) return attendance["MATHS"] || 75;
    if (upperSub.includes('DSA')) return attendance["DSA"] || 75;
    if (upperSub.includes('WEB')) return attendance["WEB"] || 75;
    if (upperSub.includes('AJP')) return attendance["AJP"] || 75;
    return attendance[upperSub] || 75;
  };

  const updateAttendance = (subject: string, status: 'present' | 'absent') => {
    setAttendance(prev => {
      let key = subject.toUpperCase();
      if (key.includes('MATH')) key = "MATHS";
      else if (key.includes('DSA')) key = "DSA";
      else if (key.includes('WEB')) key = "WEB";
      else if (key.includes('AJP')) key = "AJP";
      
      const current = prev[key] || 75;
      const delta = status === 'present' ? 1 : -3;
      const next = Math.max(0, Math.min(100, current + delta));
      return { ...prev, [key]: next };
    });
  };

  const themes = {
    default: {
      bg: "bg-violet-50",
      border: "border-violet-100",
      shadow: "shadow-violet-200/50",
      accent: "bg-indigo-600",
      emptyBorder: "border-violet-200"
    },
    cyber: {
      bg: "bg-slate-900 border-slate-800",
      border: "border-cyan-500/30",
      shadow: "shadow-cyan-500/20",
      accent: "bg-cyan-600",
      emptyBorder: "border-slate-700"
    },
    royal: {
      bg: "bg-rose-50",
      border: "border-rose-100",
      shadow: "shadow-rose-200/50",
      accent: "bg-rose-600",
      emptyBorder: "border-rose-200"
    },
    forest: {
      bg: "bg-emerald-50",
      border: "border-emerald-100",
      shadow: "shadow-emerald-200/50",
      accent: "bg-emerald-600",
      emptyBorder: "border-emerald-200"
    }
  };

  const theme = themes[currentTheme];

  const hours = [1, 2, 'BREAK', 3, 4, 5, 'LUNCH', 6, 7, 'BREAK', 8, 9];

  const handleSaveHomework = (newHomework: string) => {
    if (!selectedSlot) return;
    
    setTimetable(prev => prev.map(day => {
      if (day.day === selectedSlot.day) {
        return {
          ...day,
          slots: day.slots.map(slot => {
            if (slot.hour === selectedSlot.hour) {
              return { ...slot, homework: newHomework };
            }
            return slot;
          })
        };
      }
      return day;
    }));
    setSelectedSlot(null);
  };

  const handleUpdateSlot = (newSubject: string) => {
    if (!editingSlot) return;
    
    setTimetable(prev => prev.map(day => {
      if (day.day === editingSlot.day) {
        return {
          ...day,
          slots: day.slots.map(slot => {
            if (slot.hour === editingSlot.hour) {
              return { ...slot, subject: newSubject };
            }
            return slot;
          })
        };
      }
      return day;
    }));
    setEditingSlot(null);
  };
  
  return (
    <div className={cn("space-y-6 animate-in fade-in duration-700 p-1 min-h-screen transition-colors duration-500", currentTheme === 'cyber' ? "bg-slate-950" : "bg-transparent")}>
      <header className="flex justify-between items-end">
        <div>
          <h1 className={cn("text-3xl font-black tracking-tight", currentTheme === 'cyber' ? "text-white" : "text-gray-900 dark:text-white")}>Academic Timeline</h1>
          <p className={cn("font-medium text-sm", currentTheme === 'cyber' ? "text-slate-400" : "text-gray-500 dark:text-gray-400")}>Visualize your weekly learning journey and assignments.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex p-1 bg-gray-100 dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700">
            {(['default', 'cyber', 'royal', 'forest'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setCurrentTheme(t)}
                className={cn(
                  "px-3 py-1.5 rounded-lg transition-all capitalize text-[10px] font-black tracking-widest",
                  currentTheme === t ? "bg-white dark:bg-gray-700 shadow-sm text-indigo-600 dark:text-indigo-400" : "text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300"
                )}
              >
                {t}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 dark:bg-indigo-900/30 rounded-full border border-indigo-100 dark:border-indigo-800">
            <div className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse" />
            <span className="text-[10px] font-black uppercase text-indigo-600 dark:text-indigo-400 tracking-wider">Session Active</span>
          </div>
          <button 
            onClick={() => setIsCustomizing(!isCustomizing)}
            className={cn(
              "flex items-center gap-2 px-4 py-1.5 rounded-full border transition-all font-black text-[10px] uppercase tracking-widest",
              isCustomizing 
                ? "bg-rose-50 dark:bg-rose-900/30 border-rose-200 dark:border-rose-800 text-rose-600 dark:text-rose-400 shadow-lg shadow-rose-100 dark:shadow-none" 
                : "bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-indigo-300 dark:hover:border-indigo-700 hover:text-indigo-600 dark:hover:text-indigo-400"
            )}
          >
            <Settings className={cn("w-3.5 h-3.5", isCustomizing && "animate-spin")} />
            {isCustomizing ? "Exit Edit" : "Customize"}
          </button>
        </div>
      </header>

      <div className={cn("rounded-[2rem] border transition-all duration-500 overflow-hidden shadow-2xl", theme.bg, theme.border, theme.shadow)}>
        <div className="overflow-x-auto">
          <table className="w-full text-center border-collapse table-fixed min-w-[950px]">
            <thead>
              <tr className={cn(currentTheme === 'cyber' ? "bg-slate-800/50" : "bg-gray-50/50", "text-gray-400")}>
                <th className="p-3 text-[10px] font-black uppercase tracking-[0.2em] w-24">Timeline</th>
                {hours.map((h, i) => (
                  <th 
                    key={i} 
                    className={cn(
                      "p-3 text-[10px] font-black uppercase tracking-[0.2em]",
                      typeof h === 'string' ? "w-14" : "w-20"
                    )}
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className={cn("divide-y", currentTheme === 'cyber' ? "divide-slate-800" : "divide-violet-100")}>
              {timetable.map((dayEntry) => (
                <tr key={dayEntry.day} className={cn("group transition-colors duration-300", currentTheme === 'cyber' ? "hover:bg-cyan-500/10" : "hover:bg-violet-100/30")}>
                  <td className={cn("p-2 sticky left-0 z-10 transition-colors", theme.bg, currentTheme === 'cyber' ? "group-hover:bg-slate-800" : "group-hover:bg-violet-100")}>
                    <div className={cn("text-white rounded-2xl py-2 font-black text-[11px] uppercase tracking-widest shadow-lg", theme.accent)}>
                      {dayEntry.day}
                    </div>
                  </td>
                  
                  {dayEntry.isDayOrder ? (
                    <>
                      <td colSpan={2} className="p-1">
                        <div className="h-10 w-full bg-amber-50 text-amber-700 rounded-xl flex items-center justify-center font-bold text-[10px] uppercase tracking-widest border border-amber-100 shadow-sm italic">
                          Special Day Order
                        </div>
                      </td>
                      <td className="p-1 bg-gray-50/30 flex items-center justify-center h-10 my-1">
                        <span style={{ writingMode: 'vertical-rl' }} className="rotate-180 text-gray-300 font-black text-[8px] tracking-widest">REST</span>
                      </td>
                      <td colSpan={3} className="p-1">
                        <div className="h-10 w-full bg-amber-50 text-amber-700 rounded-xl flex items-center justify-center font-bold text-[10px] uppercase tracking-widest border border-amber-100 shadow-sm italic">
                          Special Day Order
                        </div>
                      </td>
                      <td className="p-1 bg-gray-50/30 flex items-center justify-center h-10 my-1">
                        <span style={{ writingMode: 'vertical-rl' }} className="rotate-180 text-gray-300 font-black text-[8px] tracking-widest leading-none">RECHARGE</span>
                      </td>
                      <td colSpan={2} className="p-1">
                        <div className="h-10 w-full bg-amber-50 text-amber-700 rounded-xl flex items-center justify-center font-bold text-[10px] uppercase tracking-widest border border-amber-100 shadow-sm italic">
                          Special Day Order
                        </div>
                      </td>
                      <td className="p-1 bg-gray-50/30 flex items-center justify-center h-10 my-1">
                        <span style={{ writingMode: 'vertical-rl' }} className="rotate-180 text-gray-300 font-black text-[8px] tracking-widest">REST</span>
                      </td>
                      <td colSpan={2} className="p-1">
                        <div className="h-10 w-full bg-amber-50 text-amber-700 rounded-xl flex items-center justify-center font-bold text-[10px] uppercase tracking-widest border border-amber-100 shadow-sm italic">
                          Special Day Order
                        </div>
                      </td>
                    </>
                  ) : (
                    hours.map((h, hourIdx) => {
                      if (h === 'BREAK' || h === 'LUNCH') {
                        return (
                          <td 
                            key={`break-${hourIdx}`} 
                            className="p-1 bg-gray-50/50 relative overflow-hidden"
                          >
                            <div className="h-10 flex items-center justify-center font-black text-[9px] uppercase tracking-[0.3em] text-gray-300/60" style={{ writingMode: 'vertical-rl' }}>
                              <span className="rotate-180">{h}</span>
                            </div>
                          </td>
                        );
                      }

                      const currentHour = h as number;
                      const slot = dayEntry.slots.find(s => s.hour === currentHour);

                      const isCovered = dayEntry.slots.some(s => s.hour < currentHour && (s.hour + (s.span || 1) > currentHour));
                      if (isCovered) return null;

                      if (slot) {
                        return (
                          <td 
                            key={`slot-${currentHour}`} 
                            colSpan={slot.span || 1} 
                            className="p-1"
                          >
                            <button
                              onClick={() => {
                                if (isCustomizing) {
                                  setEditingSlot({ day: dayEntry.day, hour: slot.hour, subject: slot.subject, color: slot.color });
                                } else {
                                  setSelectedSlot({ day: dayEntry.day, hour: slot.hour, subject: slot.subject, homework: slot.homework });
                                }
                              }}
                              className={cn(
                                "h-11 w-full flex flex-col items-center justify-center p-1 rounded-xl text-[10px] font-black uppercase tracking-wider text-white leading-tight transition-all duration-300 hover:scale-[1.03] hover:shadow-lg active:scale-95 group relative overflow-hidden",
                                isCustomizing && "ring-2 ring-white ring-offset-2 ring-offset-indigo-500 scale-[1.02]",
                                slot.color?.replace('bg-', 'bg-gradient-to-br from-') || "bg-gradient-to-br from-orange-500 to-orange-600 shadow-orange-100",
                                slot.color && `to-${slot.color.split('-')[1]}-700`
                              )}
                            >
                              <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                              <span className="relative z-10">{slot.subject}</span>
                              <span className="text-[7px] font-black opacity-60 mt-0.5 tracking-tighter">
                                {getSubjectAttendance(slot.subject)}% ATT
                              </span>
                              {isCustomizing && (
                                <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                  <Settings className="w-4 h-4" />
                                </div>
                              )}
                              {!isCustomizing && slot.homework && (
                                <div className="absolute top-1 right-1 flex gap-0.5">
                                  <div className="w-1.5 h-1.5 bg-white rounded-full animate-ping" />
                                  <div className="w-1.5 h-1.5 bg-white rounded-full absolute" />
                                </div>
                              )}
                            </button>
                          </td>
                        );
                      }

                      return <td key={`empty-${currentHour}`} className="p-1">
                        <div className={cn("h-10 w-full border border-dashed rounded-xl", theme.emptyBorder)} />
                      </td>;
                    })
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Monthly Attendance Calendar */}
      <div className={cn(
        "rounded-[2.5rem] border p-8 space-y-6 shadow-2xl transition-all duration-500",
        theme.bg, theme.border, theme.shadow
      )}>
        {/* Section Header */}
        <div className={cn(
          "flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b pb-6",
          currentTheme === 'cyber' ? "border-slate-800" : "border-violet-100"
        )}>
          <div className="flex items-center gap-4">
            <div className={cn("p-4 rounded-3xl text-white shadow-lg", theme.accent)}>
              <Calendar className="w-6 h-6" />
            </div>
            <div>
              <h2 className={cn("text-2xl font-black tracking-tight", currentTheme === 'cyber' ? "text-white" : "text-gray-900 dark:text-white")}>Attendance Log</h2>
              <p className={cn("text-xs font-semibold mt-0.5", currentTheme === 'cyber' ? "text-slate-400" : "text-gray-500 dark:text-gray-400")}>Log your daily attendance. Select a date in the calendar below to mark it.</p>
            </div>
          </div>

          {/* Month Navigation Controls */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (currentMonth === 0) {
                  setCurrentMonth(11);
                  setCurrentYear(prev => prev - 1);
                } else {
                  setCurrentMonth(prev => prev - 1);
                }
              }}
              className="p-3 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:border-indigo-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all font-bold text-gray-600 dark:text-gray-300 active:scale-95"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="px-5 py-3 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 font-black text-xs uppercase tracking-widest text-gray-700 dark:text-gray-200 min-w-[140px] text-center shadow-inner">
              {months[currentMonth]} {currentYear}
            </div>
            <button
              onClick={() => {
                if (currentMonth === 11) {
                  setCurrentMonth(0);
                  setCurrentYear(prev => prev + 1);
                } else {
                  setCurrentMonth(prev => prev + 1);
                }
              }}
              className="p-3 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:border-indigo-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all font-bold text-gray-600 dark:text-gray-300 active:scale-95"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Bento Grid layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Calendar Grid Container */}
          <div className="lg:col-span-8 space-y-4 text-left">
            {/* Weekdays Header */}
            <div className="grid grid-cols-7 text-center font-black text-[10px] uppercase tracking-[0.2em] text-gray-400 dark:text-slate-500 pb-2 border-b border-gray-100 dark:border-slate-800/40">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((dayName) => (
                <div key={dayName} className="py-1">{dayName}</div>
              ))}
            </div>

            {/* Days Grid */}
            <div className="grid grid-cols-7 gap-2">
              {calendarCellsWithPadding.map((cell, idx) => {
                const dateKey = formatDateString(cell.year, cell.month, cell.day);
                const status = dailyAttendance[dateKey];
                const isSelected = selectedCalDate === dateKey;
                const isToday = today.getDate() === cell.day && today.getMonth() === cell.month && today.getFullYear() === cell.year;
                
                return (
                  <button
                    key={`${dateKey}-${idx}`}
                    onClick={() => setSelectedCalDate(dateKey)}
                    className={cn(
                      "aspect-square rounded-2xl flex flex-col items-center justify-between p-1.5 border relative transition-all duration-300 group text-left",
                      cell.isCurrentMonth 
                        ? (currentTheme === 'cyber' ? "bg-slate-850/40 text-slate-100 border-slate-800" : "bg-white dark:bg-gray-800 hover:scale-[1.03] border-gray-100 dark:border-gray-700 hover:shadow-md")
                        : "opacity-45 text-gray-400 dark:text-slate-600 border-transparent cursor-not-allowed",
                      isSelected && calTheme.activeDayRing,
                      status === 'present' && "bg-gradient-to-br from-emerald-500/10 to-emerald-500/20 border-emerald-500/30 text-emerald-600 dark:text-emerald-400",
                      status === 'absent' && "bg-gradient-to-br from-rose-500/10 to-rose-500/20 border-rose-500/30 text-rose-600 dark:text-rose-400"
                    )}
                  >
                    {/* Day Number */}
                    <span className={cn(
                      "text-xs font-black self-start ml-1 mt-0.5",
                      isToday && "text-indigo-600 dark:text-indigo-400 underline decoration-2 underline-offset-4"
                    )}>
                      {cell.day}
                    </span>

                    {/* Badge Indicator */}
                    <div className="w-full flex justify-center pb-0.5">
                      {status === 'present' && (
                        <div className="flex items-center justify-center gap-0.5 px-2 py-0.5 rounded-full bg-emerald-500 text-white text-[7px] font-black uppercase tracking-wider scale-95 md:scale-100">
                          <Check className="w-2 h-2 stroke-[4px]" />
                          <span>P</span>
                        </div>
                      )}
                      {status === 'absent' && (
                        <div className="flex items-center justify-center gap-0.5 px-2 py-0.5 rounded-full bg-rose-500 text-white text-[7px] font-black uppercase tracking-wider scale-95 md:scale-100">
                          <X className="w-2 h-2 stroke-[4px]" />
                          <span>A</span>
                        </div>
                      )}
                      {!status && cell.isCurrentMonth && (
                        <div className="w-1.5 h-1.5 rounded-full bg-gray-200 dark:bg-gray-700 group-hover:bg-indigo-400 transition-colors" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sidebar: Control Panel & Month Statistics */}
          <div className="lg:col-span-4 space-y-6 flex flex-col justify-between text-left">
            {/* Current Day Action Form */}
            <div className={cn(
              "rounded-3xl p-6 border space-y-4 shadow-sm",
              currentTheme === 'cyber' ? "bg-slate-900/50 border-slate-800" : "bg-gray-50/50 border-gray-100 dark:border-gray-800"
            )}>
              <div className="border-b border-gray-100 dark:border-gray-800 pb-3">
                <p className="text-[9px] font-black uppercase tracking-widest text-indigo-500 dark:text-indigo-400">Selected Day</p>
                <p className={cn("text-xs font-black mt-1", calTheme.text)}>
                  {getReadableDate(selectedCalDate)}
                </p>
                {/* Status indicator */}
                <div className="mt-2 flex items-center gap-1.5">
                  <span className="text-[10px] font-bold text-gray-400">Current Log:</span>
                  {dailyAttendance[selectedCalDate] === 'present' ? (
                    <span className="text-[9px] font-black bg-emerald-500/10 text-emerald-600 px-2 py-0.5 rounded-md border border-emerald-500/20 uppercase tracking-widest">Present</span>
                  ) : dailyAttendance[selectedCalDate] === 'absent' ? (
                    <span className="text-[9px] font-black bg-rose-500/10 text-rose-600 px-2 py-0.5 rounded-md border border-rose-500/20 uppercase tracking-widest">Absent</span>
                  ) : (
                    <span className="text-[9px] font-black bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 px-2 py-0.5 rounded-md uppercase tracking-widest">No Log</span>
                  )}
                </div>
              </div>

              {/* Attendance Quick Controls */}
              <div className="space-y-3">
                <button
                  onClick={() => updateDailyAttendance(selectedCalDate, 'present')}
                  className={cn(
                    "w-full flex items-center justify-between px-5 py-3.5 border rounded-2xl font-black text-xs uppercase tracking-widest transition-all hover:scale-[1.02] active:scale-95 shadow-sm",
                    calTheme.btnPresent
                  )}
                >
                  <span className="flex items-center gap-2">
                    <Check className="w-4 h-4" />
                    Mark Present
                  </span>
                </button>
                <button
                  onClick={() => updateDailyAttendance(selectedCalDate, 'absent')}
                  className={cn(
                    "w-full flex items-center justify-between px-5 py-3.5 border rounded-2xl font-black text-xs uppercase tracking-widest transition-all hover:scale-[1.02] active:scale-95 shadow-sm",
                    calTheme.btnAbsent
                  )}
                >
                  <span className="flex items-center gap-2">
                    <X className="w-4 h-4" />
                    Mark Absent
                  </span>
                </button>
                <button
                  onClick={() => updateDailyAttendance(selectedCalDate, 'none')}
                  className={cn(
                    "w-full flex items-center justify-center gap-2 px-5 py-3 border rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all opacity-80 hover:opacity-100 hover:scale-[1.02] active:scale-95",
                    calTheme.btnClear
                  )}
                >
                  Clear Status
                </button>
              </div>
            </div>

            {/* Quick Stats Summary Card */}
            <div className={cn(
              "rounded-3xl p-6 border flex flex-col justify-between text-left h-full",
              currentTheme === 'cyber' ? "bg-slate-900 border-cyan-500/10" : "bg-white dark:bg-gray-800 border-gray-100 dark:border-gray-700 shadow-sm"
            )}>
              <div>
                <h4 className={cn("text-xs font-black uppercase tracking-widest mb-4", currentTheme === 'cyber' ? "text-cyan-400" : "text-gray-400 dark:text-gray-500")}>
                  {months[currentMonth]} Summary
                </h4>
                
                <div className="space-y-3">
                  <div className="flex justify-between items-center bg-gray-50/50 dark:bg-slate-800/30 p-2.5 rounded-xl border border-gray-100/50 dark:border-slate-800/20">
                    <span className="text-[10px] font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">Present Days</span>
                    <span className="text-sm font-black text-emerald-600 dark:text-emerald-400">{monthStats.present}</span>
                  </div>
                  <div className="flex justify-between items-center bg-gray-50/50 dark:bg-slate-800/30 p-2.5 rounded-xl border border-gray-100/50 dark:border-slate-800/20">
                    <span className="text-[10px] font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">Absent Days</span>
                    <span className="text-sm font-black text-rose-600 dark:text-rose-400">{monthStats.absent}</span>
                  </div>
                  <div className="flex justify-between items-center bg-gray-50/50 dark:bg-slate-800/30 p-2.5 rounded-xl border border-gray-100/50 dark:border-slate-800/20">
                    <span className="text-[10px] font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">Total Logged</span>
                    <span className={cn("text-sm font-black", calTheme.text)}>{monthStats.total}</span>
                  </div>
                </div>
              </div>

              {/* Progress/Metric Visualizer */}
              <div className="mt-5 border-t border-gray-100 dark:border-gray-700/60 pt-4 space-y-2">
                <div className="flex justify-between items-end">
                  <span className="text-[10px] font-black uppercase tracking-wider text-gray-400">Monthly Attendance</span>
                  <span className={cn(
                    "text-xl font-black",
                    monthStats.percentage >= 80 ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400"
                  )}>
                    {monthStats.percentage}%
                  </span>
                </div>
                <div className="h-2 w-full bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div 
                    className={cn(
                      "h-full rounded-full transition-all duration-500",
                      monthStats.percentage >= 80 ? "bg-emerald-500" : "bg-rose-500"
                    )}
                    style={{ width: `${monthStats.percentage}%` }}
                  />
                </div>
                <p className="text-[8px] font-bold text-gray-400 leading-normal">
                  {monthStats.percentage >= 80 
                    ? "✓ Attendance is in good standing (above target 80% requirement)." 
                    : "⚠️ Warning: attendance is below the 80% target threshold."}
                </p>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Enhanced Homework Modal */}
      <AnimatePresence>
        {selectedSlot && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-gray-900/40 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 20 }}
              className="bg-white dark:bg-gray-900 w-full max-w-md rounded-[3rem] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.2)] overflow-hidden border border-white/20 dark:border-gray-800"
            >
              <div className="p-8 bg-indigo-600 text-white relative overflow-hidden">
                <div className="absolute -top-12 -right-12 w-48 h-48 bg-white/10 rounded-full blur-3xl opacity-50" />
                <div className="flex justify-between items-start relative z-10">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-white/20 backdrop-blur-xl rounded-2xl border border-white/30">
                      <StickyNote className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-100 mb-1">Session Insights</p>
                      <h3 className="font-black text-2xl leading-tight tracking-tight">{selectedSlot.subject}</h3>
                    </div>
                  </div>
                  <button onClick={() => setSelectedSlot(null)} className="p-2 bg-white/10 hover:bg-white/20 rounded-full transition-all active:scale-90">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="mt-6 flex items-center gap-3">
                  <span className="px-3 py-1 bg-indigo-500/50 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/10">
                    {selectedSlot.day}
                  </span>
                  <span className="px-3 py-1 bg-indigo-500/50 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/10">
                    HOUR {selectedSlot.hour}
                  </span>
                  <span className={cn(
                    "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/10",
                    getSubjectAttendance(selectedSlot.subject) >= 75 ? "bg-emerald-500/50" : "bg-rose-500/50"
                  )}>
                    {getSubjectAttendance(selectedSlot.subject)}% Attendance
                  </span>
                </div>
              </div>
              <div className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <button 
                    onClick={() => updateAttendance(selectedSlot.subject, 'present')}
                    className="flex flex-col items-center justify-center p-4 rounded-3xl bg-emerald-50 border-2 border-emerald-100 text-emerald-700 hover:bg-emerald-100 transition-all active:scale-95"
                  >
                    <span className="text-sm font-black uppercase tracking-widest">Present</span>
                    <span className="text-[10px] font-bold opacity-60">+1% Bonus</span>
                  </button>
                  <button 
                    onClick={() => updateAttendance(selectedSlot.subject, 'absent')}
                    className="flex flex-col items-center justify-center p-4 rounded-3xl bg-rose-50 border-2 border-rose-100 text-rose-700 hover:bg-rose-100 transition-all active:scale-95"
                  >
                    <span className="text-sm font-black uppercase tracking-widest">Absent</span>
                    <span className="text-[10px] font-bold opacity-60">-3% Penalty</span>
                  </button>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-1">Homework & Actionables</label>
                  <textarea 
                    autoFocus
                    defaultValue={selectedSlot.homework || ''}
                    placeholder="Enter tasks or key points discussed..."
                    className="w-full h-40 p-6 bg-gray-50 dark:bg-gray-800 border-2 border-gray-100 dark:border-gray-700 rounded-3xl focus:outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-400/50 transition-all font-bold text-gray-700 dark:text-gray-100 placeholder:text-gray-300 dark:placeholder:text-gray-600 placeholder:font-medium text-sm leading-relaxed"
                    id="homework-textarea"
                  />
                </div>
                <button 
                  onClick={() => {
                    const el = document.getElementById('homework-textarea') as HTMLTextAreaElement;
                    handleSaveHomework(el.value);
                  }}
                  className="w-full bg-indigo-600 text-white py-5 rounded-[2rem] font-black uppercase tracking-[0.2em] hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200 flex items-center justify-center gap-3 group active:scale-[0.98]"
                >
                  Confirm Entry
                  <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Customize Subject Modal */}
      <AnimatePresence>
        {editingSlot && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-gray-900/60 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 20 }}
              className="bg-white dark:bg-gray-900 w-full max-w-sm rounded-[3rem] shadow-2xl overflow-hidden border border-white/20 dark:border-gray-800"
            >
              <div className="p-8 bg-rose-600 text-white relative">
                <div className="flex justify-between items-start relative z-10">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-white/20 backdrop-blur-xl rounded-2xl border border-white/30">
                      <Settings className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-[0.2em] text-rose-100 mb-1">Configuration</p>
                      <h3 className="font-black text-2xl tracking-tight">Edit Subject</h3>
                    </div>
                  </div>
                  <button onClick={() => setEditingSlot(null)} className="p-2 bg-white/10 hover:bg-white/20 rounded-full transition-all">
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
              <div className="p-8 space-y-6">
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-1">Subject Name</label>
                  <input 
                    autoFocus
                    type="text"
                    defaultValue={editingSlot.subject}
                    id="subject-input"
                    className="w-full p-6 bg-gray-50 dark:bg-gray-800 border-2 border-gray-100 dark:border-gray-700 rounded-3xl focus:outline-none focus:ring-4 focus:ring-rose-500/10 focus:border-rose-400/50 transition-all font-bold text-gray-700 dark:text-white"
                  />
                </div>
                <button 
                  onClick={() => {
                    const el = document.getElementById('subject-input') as HTMLInputElement;
                    handleUpdateSlot(el.value);
                  }}
                  className="w-full bg-rose-600 text-white py-5 rounded-[2rem] font-black uppercase tracking-[0.2em] hover:bg-rose-700 transition-all shadow-xl shadow-rose-200 flex items-center justify-center gap-3 group"
                >
                  Update Slot
                  <Save className="w-5 h-5 group-hover:scale-110 transition-transform" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
