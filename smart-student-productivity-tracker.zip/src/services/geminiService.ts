import { GoogleGenAI, Type } from "@google/genai";
import { PerformanceRecord } from "../types";

// Initialization - In AI Studio, process.env.GEMINI_API_KEY is automatically available
const GEMINI_KEY = process.env.GEMINI_API_KEY;

const ai = new GoogleGenAI({ 
  apiKey: GEMINI_KEY || '' 
});

const MODEL_NAME = "gemini-3-flash-preview";

export async function chatWithAi(message: string, history: { role: string, parts: { text: string }[] }[], files?: { mimeType: string, data: string }[]) {
  try {
    const userParts = [{ text: message }];
    if (files && files.length > 0) {
      files.forEach(file => {
        userParts.push({ inlineData: file } as any);
      });
    }

    const result = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: [...(history || []), { role: 'user', parts: userParts }],
      config: {
        systemInstruction: "You are a helpful student AI tutor. Provide clear, encouraging, and accurate explanations for academic topics. If the user uploads a file or image, analyze it and provide relevant academic help."
      }
    });
    return result.text;
  } catch (error) {
    console.error("Gemini Chat Error:", error);
    throw error;
  }
}

export async function summarizeText(text: string) {
  try {
    const result = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: [{ role: 'user', parts: [{ text: `Summarize the following educational content concisely into key bullet points:\n\n${text}` }] }],
      config: {
        systemInstruction: "You are a professional notes summarizer for students. Extract key concepts and actionable insights."
      }
    });
    return result.text;
  } catch (error) {
    console.error("Gemini Summarize Error:", error);
    throw error;
  }
}

export async function generateQuiz(topic: string) {
  try {
    const result = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: [{ role: 'user', parts: [{ text: `Create a 5-question multiple choice quiz about "${topic}".` }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING },
                description: "Four multiple choice options"
              },
              answer: { 
                type: Type.STRING,
                description: "The correct option exactly as it appears in the options array"
              }
            },
            required: ["question", "options", "answer"]
          }
        }
      }
    });
    
    if (!result.text) return [];
    return JSON.parse(result.text);
  } catch (error) {
    console.error("Gemini Quiz Error:", error);
    throw error;
  }
}

export async function generateStudyPlan(input: string) {
  try {
    const result = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: [{ role: 'user', parts: [{ text: `Create a detailed and realistic study plan based on this request: ${input}` }] }],
      config: {
        systemInstruction: "You are an expert academic advisor and study planner. Create structured schedules with time blocks, topics, and specific study techniques (like Active Recall or Pomodoro)."
      }
    });
    return result.text;
  } catch (error) {
    console.error("Gemini Study Plan Error:", error);
    throw error;
  }
}

export async function analyzePerformance(marks: PerformanceRecord[]) {
  try {
    const result = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: [{ role: 'user', parts: [{ text: `Analyze these student marks and provide constructive feedback, trends, and focus areas: ${JSON.stringify(marks)}` }] }],
      config: {
        systemInstruction: "You are a supportive academic performance analyst. Be encouraging but honest about areas needing improvement."
      }
    });
    return result.text;
  } catch (error) {
    console.error("Gemini Performance Analysis Error:", error);
    throw error;
  }
}
