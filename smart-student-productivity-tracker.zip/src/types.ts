export interface Task {
  id: string;
  title: string;
  dueDate: string;
  status: 'Pending' | 'Done';
}

export interface AttendanceRecord {
  subject: string;
  attended: number;
  total: number;
}

export interface TimetableSlot {
  subject: string;
  hour: number; // 1-9
  span?: number; // How many hours it covers
  color?: string; // Optional color hex or class name
  homework?: string;
}

export interface TimetableEntry {
  day: string;
  slots: TimetableSlot[];
  isDayOrder?: boolean;
}

export interface PerformanceRecord {
  subject: string;
  test1: number;
  test2: number;
  semResult: number;
  final: number;
}

export interface User {
  name: string;
  email: string;
  course: string;
  year: string;
  cgpa: number;
  rollNo?: string;
  section?: string;
  campus?: string;
  profilePic?: string;
  arrears?: number;
}
